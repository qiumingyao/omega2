#ifndef OVERLAPGRAPH_H
#define OVERLAPGRAPH_H

//============================================================================
// Name        : OverlapGraph.h
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : OverlapGraph header file
//============================================================================

#include "Config.h"
#include "DataSet.h"
#include "Edge.h"

class OverlapGraph
{
	private:
		DataSet *dataSet;

		// Adjacency list of the graph.
		vector< vector<Edge *> * > *graph;	

		// For saving deleted edges
		vector<Edge *> * deletedEdges;    

		UINT64 numberOfNodes;
		UINT64 numberOfEdges;
		UINT64 minOvl;
		bool flowComputed;

		// Insert an edge in the overlap graph
		void insertEdge(Edge * edge);

		// Insert an edge in the overlap graph
		void insertEdge(Read *read1, Read *read2, UINT8 orient, 
				UINT32 overlapOffset, vector<pair<UINT32, UINT32> > *mismatchesInput);

		// Get reverse mismatch positions
		void getReverseMismatches(const vector<pair<UINT32, UINT32> > *mismatchesInput, 
				const UINT32 & numberOfContained, const UINT32 & overlapOffset, 
				const UINT32 & read2Length, 
				vector<pair<UINT32, UINT32> > *reverseMismatchesInput);

		// Orientation of the reverse edge.
		UINT8 twinEdgeOrientation(const UINT8 & orientation);

		// Merge two edges in the  overlap graph.
		void mergeEdges(Edge *edge1, Edge *edge2);

		// When we merge two edges, need to merge the list of ordered reads, 
		// their overlap offsets and orientations.
		void mergeList(const Edge *edge1, const Edge *edge2, vector<UINT64> *listReads, 
				vector<UINT32> *listOverlapOffsets, vector<UINT8> * ListOrientations);

		// Orientation of the edge when two edges are merged.
		UINT8 mergedEdgeOrientation(const Edge *edge1, const Edge *edge2);

		// Remove an edge from the overlap graph.
		void removeEdge(Edge *edge, bool save_for_contig=false);

		// Break an edges at specified link
		vector<Edge*> breakForwardEdge(Edge *edge, UINT64 link = 0);

		void breakEdge(Edge *edge, UINT64 link = 0);

		// Remove the location of all the reads from the current edge. 
		// This function is called when an edge is removed.
		void removeReadLocations(Edge *edge);

		// Update the location of all the reads in the current edge. 
		// This function is called when a new edge is inserted.
		void updateReadLocations(Edge *edge);

		// Contract composite paths in the overlap graph.
		UINT64 contractCompositeEdges(void);

		// Remove dead-ends from the overlap graph.
		UINT64 removeDeadEndNodes(void);

		// Remove dead-end like short branches, if they are much shorter 
		// than other longer edges even though they are longer than
		// the dead-end length threshold
		UINT64 removeShortBranches(void);

		// remove multi-edges with similar strings
		UINT64 removeSimilarEdges(void);

		// Find the edit distance between two strings. Used by removeSimilarEdges()
		UINT64 calculateEditDistance(const string & s1, const string & s2);

		// Get the coverage Mean and SD of an edge. Only considering the unique reads.
		void getBaseByBaseCoverage(Edge *edge);

		// Clip branches with much shorter overlap length
		// comparing to other branches.
		UINT64 clipBranches(void);

		// Remove trees in the overlap graph.
		UINT64 reduceTrees(void);

		// Loops that can be traversed only one way
		UINT64 reduceLoops(void);

		// Calculate bounds and costs of flow for minimum cost flow in the overlap graph.
		void calculateBoundAndCost(const Edge *edge, INT64* FLOWLB, INT64* FLOWUB, INT64* COST);

		// Find an edge from source to destination in the overlap graph.
		Edge *findEdge(const UINT64 & source, const UINT64 & destination);

		vector<Edge *> findEdges(const UINT64 & source, const UINT64 & destination);

	public:

		OverlapGraph(void);

		~OverlapGraph();

		// Keep track of number of reads contained in the edges with 1 unit of flow assigned 
		static int s_nReads_in_goodEdges; 

		// keep track of number of edges with 1 unit of flow assigned 
		static int s_nGoodEdges;        

		UINT64 getNumberOfEdges(void) const {return numberOfEdges;}

		UINT64 getNumberOfNodes(void) const {return numberOfNodes;}

		void setDataSet(DataSet *dataset){dataSet=dataset;}

		void setMinOvl(const UINT64 & minOvl = 50){this->minOvl = minOvl;}

		// Build the overlap graph from read/edge files.
		void buildOverlapGraphFromFiles(const vector<string> &readFilenameList, 
				const vector<string> &edgeFilenameList);

		// Load read file, return count (the number of reads in the file)
		UINT64 loadReadFileWithoutSequences(const string &readFilename, 
				unordered_map<UINT64, UINT64> &readIDMap, UINT64 &readID);

		// Load read file again to print contigs
		UINT64 streamReadFileSequences(const string &readFilename, UINT64 &readID, 
				vector<vector<char> > & contigStrings, 
				vector<unordered_map<UINT32, vector<char> > > & mismatchMap);

		// Load edge file
		void loadEdgeFile(const string &readFilename, const unordered_map<UINT64, UINT64> &readIDMap);

		// Sort edges of each read based on ID of the destination read. 
		// This is only for ordering edges for convenience in the output file
		void sortEdges();

		// Some simple simplification.
		void simplifyGraph(void);

		// Calculate the minimum cost flow of the overlap graph using file
		void calculateFlowStream(void);

		// Remove all simple edges without flow
		UINT64 removeAllEdgesWithoutFlow();

		// Find all the edges in the graph, to be used in print graph and contigs
		void getEdges(vector<Edge *> & contigEdges);
		
		// Store the overlap graph for visual display and also store the contigs/scaffods in a file.
		void printGraph(const string & graphFileName, const vector<Edge *> & contigEdges);

		void printContigsStream(const vector<string> &readFilenameList, 
				const string & contigFastaFilename, vector<Edge *> & contigEdges);


};

#endif /* OVERLAPGRAPH_H */
