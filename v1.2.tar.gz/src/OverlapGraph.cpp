//============================================================================
// Name        : OverlapGraph.cpp
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : OverlapGraph cpp file
//============================================================================

#include "Config.h"
#include "OverlapGraph.h"
#include "CS2_stream/cs2.h"

extern TLogLevel loglevel;/* verbosity level of logging */
//=============================================================================
// Check if two edges match.
// e1(u,v) and e2(v,w). At node v, one of the edges should be an incoming edge and the other should be an outgoing
// edge to match.
//=============================================================================
bool matchEdgeType(const Edge *edge1, const Edge *edge2)
{
	if( (edge1->getOrientation() == 1 || edge1->getOrientation() == 3) && (edge2->getOrientation() == 2 || edge2->getOrientation() == 3) ) // *-----> and >------*
		return true;
	else if( (edge1->getOrientation() == 0 || edge1->getOrientation() == 2) && (edge2->getOrientation() == 0 || edge2->getOrientation() == 1) ) // *------< and <------*
		return true;
	return false;
}


//=============================================================================
// Function to compare two edges by the destination read number. 
// The read number was determined by the read string lexicographically.
// Used for sorting.
//=============================================================================
bool compareEdgeID (const Edge *edge1, const Edge* edge2)
{
	return (edge1->getDestinationRead()->getReadNumber() < edge2->getDestinationRead()->getReadNumber());
}


//=============================================================================
// Function to compare two edges by overlap offset. 
// Used for transitive edge removal (which is not included any more)
//=============================================================================
bool compareEdgesByOffset (const Edge *edge1, const Edge* edge2)
{
	return (edge1->getOverlapOffset() < edge2->getOverlapOffset());
}



/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  compareEdgesByReads
 *  Description:  Compare edges by number of reads contained in the them
 * =====================================================================================
 */
bool compareEdgesByReads (const Edge *edge1, const Edge* edge2)
{
	return (edge1->getListOfReads()->size() > edge2->getListOfReads()->size());
}


//=============================================================================
// Function to compare two string length
//=============================================================================
bool compareStringByLength (const string & seq1, const string & seq2)
{
	return (seq1.length() < seq2.length());
}


//=============================================================================
// Default constructor
//=============================================================================
OverlapGraph::OverlapGraph(void)
{
	numberOfNodes = 0;
	numberOfEdges = 0;
	flowComputed = false;
	minOvl = 0;
	deletedEdges = new vector<Edge *>;
}


//=============================================================================
// Default destructor
//=============================================================================
OverlapGraph::~OverlapGraph()
{
	// Free the memory used by the overlap graph.
	if (deletedEdges != nullptr){
		for(UINT64 i = 0 ; i < deletedEdges->size(); ++i){
			if (deletedEdges->at(i) != nullptr)
				delete deletedEdges->at(i);
		}
		delete deletedEdges;
	}
	if (graph!= nullptr){
		for(UINT64 i = 0; i < graph->size(); i++) {
			if (graph->at(i) != nullptr){
				for(UINT64 j = 0; j< graph->at(i)->size(); j++) {
					if (graph->at(i)->at(j) != nullptr)
						delete graph->at(i)->at(j);
				}
				delete graph->at(i);
			}
		}
		delete graph;
	}
}


//=============================================================================
// print readIPMap (unordered map) key=readID from the aligner, val=readID in graph
//=============================================================================
void printUnorderedMap(const unordered_map<UINT64, UINT64> & readIDMap, ostream & out)
{
	out << "ID_in_file\tID_in_omega\n";
	for(unordered_map<UINT64, UINT64>::const_iterator it=readIDMap.begin(); it!=readIDMap.end(); ++it){
		out << it->first << "\t" << it->second << endl;
	}
}


//=============================================================================
// Build overlap graph from read/edge file(s)
//=============================================================================
void OverlapGraph::buildOverlapGraphFromFiles(const vector<string> &readFilenameList, 
		const vector<string> &edgeFilenameList)
{
	CLOCKSTART;

	// Reads
	UINT64 readID(0);
	UINT64 numOfUniqueRead(0);
	UINT64 numOfUniqueReadEachFile(0);

	// save read ID from file (key=readID from overlap file, val=readID in graph)
	unordered_map<UINT64, UINT64> readIDMap;

	// loop readFilenameList
	for (vector<string>::const_iterator it = readFilenameList.begin(); 
			it != readFilenameList.end(); ++it) {
		readID = numOfUniqueRead+1;
		numOfUniqueReadEachFile = loadReadFileWithoutSequences(*it, readIDMap, readID);
		numOfUniqueRead += numOfUniqueReadEachFile;
	}

	if (numOfUniqueRead == readIDMap.size()) {
		FILE_LOG(logERROR) << "numOfUniqueRead loaded from read file(s): " << numOfUniqueRead << endl;
		dataSet->numberOfUniqueReads = numOfUniqueRead;
	}
	else {
		MYEXIT("Reads load error!");
	}

	// Initialize graph
	graph = new vector< vector<Edge *> * >;
	graph->reserve(dataSet->getNumberOfUniqueReads()+1);
	for(UINT64 i = 0; i <= dataSet->getNumberOfUniqueReads(); i++) {
		vector<Edge *> *newList = new vector<Edge *>;
		graph->push_back(newList);
	}

	// loop edgeFilenameList
	for (vector<string>::const_iterator it = edgeFilenameList.begin(); 
			it != edgeFilenameList.end(); ++it) {
		loadEdgeFile(*it, readIDMap);
	}
	FILE_LOG(logERROR) << "numberOfEdges loaded from edge file(s): " << numberOfEdges << endl;

	// When log level is at least logDEBUG, print the ID map to file
	if(loglevel > 2){
		ofstream ID_out("readIDmap.txt");
		printUnorderedMap(readIDMap, ID_out);
		ID_out.close();
	}

	// delete vector
	readIDMap.clear();

	// Sort all its incident edges according to destination read ID.
	sortEdges();

	// Composite edge contraction with remove dead end nodes
	UINT64 counter(0);
	do {
		counter = contractCompositeEdges();
		counter += removeDeadEndNodes();
		FILE_LOG(logERROR) << "numberOfEdges = " << numberOfEdges << endl;
	} while (counter > 0);
	/* disconnect the edges incident to nodes and have small overlap lengths */
	counter += clipBranches();

	CLOCKSTOP;
}


//=============================================================================
// Load read file without sequences (not save read sequence string, but just save read length)
//=============================================================================
UINT64 OverlapGraph::loadReadFileWithoutSequences(const string &readFilename, 
		unordered_map<UINT64, UINT64> & readIDMap, UINT64 &readID)
{
	CLOCKSTART;
	FILE_LOG(logINFO) << "readFilename: " << readFilename << endl;

	// To count of reads
	UINT64 readCount = 0;

	// Open file
	ifstream filePointer;
	filePointer.open(readFilename.c_str());
	if(!filePointer.is_open())
		MYEXIT("Unable to open file: "+readFilename);

	// Variables
	vector<string> line;
	string line0,line1, text;
	enum FileType {FASTA, FASTQ, UNDEFINED};
	FileType fileType = UNDEFINED;

	while(!filePointer.eof())
	{
		// Check FASTA and FASTQ
		if(fileType == UNDEFINED)
		{
			getline (filePointer,text);
			if(text[0] == '>')
				fileType = FASTA;
			else if(text[0] == '@')
				fileType = FASTQ;
			else
				cerr<< "Unknown input file format."<<endl;
			filePointer.seekg(0, ios::beg);
		}

		// Clear line
		line.clear();

		// FASTA file read
		if(fileType == FASTA)
		{
			getline (filePointer,text);	// get ID line
			line.push_back(text);
			getline (filePointer,text,'>');	// get string line
			line.push_back(text);

			line.at(1).erase(std::remove(line.at(1).begin(), line.at(1).end(), '\n'), line.at(1).end());
			line0 = line.at(0);	// ID
			line1 = line.at(1);	// String

		}
		// FASTQ file read
		else if(fileType == FASTQ)
		{
			for(UINT64 i = 0; i < 4; i++)   // Total of 4 lines represent one sequence in a FASTQ file.
			{
				getline (filePointer,text);
				line.push_back(text);
			}
			line0 = line.at(0);	// ID
			line1 = line.at(1);	// String
		}

		// Get ReadID after removing the > or @ identifier and convert string to UINT64
		string readName="";
		if(line0[0] == '>' || line0[0] == '@')
			readName = line0.substr(1);
		else readName = line0;

		// Map assign, key=readID from alinger, val=readID on graph (sequencial)
		istringstream readNameStream(readName);
		UINT64 readIDInFile;
		readNameStream >> readIDInFile;
		readIDMap[readIDInFile] = readID;

		// read = line1
		string read = line1;

		// Save to Read object
		Read *r=new Read();
		// readID, read(sequence), readLength
		r->setReadNumber(readID);
		// r->setRead(read);
		r->setReadLength(read.length());
		// add read to the dataset
		dataSet->addRead(r);
		readCount++;
		readID++;
	}
	filePointer.close();
	CLOCKSTOP;

	return readCount;
}


//=============================================================================
// Load edge file
//=============================================================================
void OverlapGraph::loadEdgeFile(const string &edgeFilename, const unordered_map<UINT64, UINT64> &readIDMap)
{
	CLOCKSTART;
	FILE_LOG(logERROR) << "Load edge file: " << edgeFilename << endl;

	// Open file
	ifstream filePointer;
	filePointer.open(edgeFilename.c_str());
	if(!filePointer.is_open() )
		MYEXIT("Unable to open file: "+edgeFilename);

	// Read file
	string text;
	while(getline(filePointer,text))
	{
		// Save text to line vector
		vector<string> line;
		std::stringstream text_ss(text);
		std::string element;

		// loop
		while (getline(text_ss, element, '\t'))
		{
			line.push_back(element);
		}

		// Get source readID
		UINT64 source_org, source;	// Tab delimited Column1: source read ID
		istringstream t1(line.at(0)); 
		t1 >> source_org;
		// Find source readID from readIDMap
		unordered_map<UINT64, UINT64>::const_iterator got_s = readIDMap.find (source_org);
		if ( got_s == readIDMap.end() ) {
			MYEXIT("not found");
		}
		else {
			source = got_s->second;
		}

		// Get destination readID
		UINT64 destination_org, destination;	// Tab delimited Column2: destination read ID
		istringstream t2(line.at(1)); t2 >> destination_org;
		// Find destination readID from readIDMap
		unordered_map<UINT64, UINT64>::const_iterator got_d = readIDMap.find (destination_org);
		if ( got_d == readIDMap.end() ) {
			MYEXIT("not found");
		}
		else {
			destination = got_d->second;
		}

		// Properties
		string properties = line.at(2);	// Tab delimited Column3: edge attributes

		// For properties list
		vector<string> propertiesList;
		std::stringstream properties_ss(properties);
		while (getline(properties_ss, element, ','))
		{
			propertiesList.push_back(element);
		}

		// properties
		UINT32 orientation;	// Property Col1: orientation
		std::istringstream p1(propertiesList.at(0)); p1 >> orientation;
		UINT32 overlapLength;	// Property Col2: overlap length
		std::istringstream p2(propertiesList.at(1)); p2 >> overlapLength;
		if (overlapLength >= minOvl){
			UINT32 substitutions;	// Property Col3: substitutions
			std::istringstream p3(propertiesList.at(2)); p3 >> substitutions;
			UINT32 edits;	// Property Col4: edit distance
			std::istringstream p4(propertiesList.at(3)); p4 >> edits;
			UINT32 length1;	// Property Col5: read1 length
			std::istringstream p5(propertiesList.at(4)); p5 >> length1;
			INT32 start1;	// Property Col6: read1 overlap start
			std::istringstream p6(propertiesList.at(5)); p6 >> start1;
			INT32 stop1;	// Property Col7: read1 overlap end
			std::istringstream p7(propertiesList.at(6)); p7 >> stop1;
			UINT32 length2;	// Property Col8: read2 length
			std::istringstream p8(propertiesList.at(7)); p8 >> length2;
			INT32 start2;	// Property Col9: read2 overlap start
			std::istringstream p9(propertiesList.at(8)); p9 >> start2;
			INT32 stop2;	// Property Col10: read2 overlap length
			std::istringstream p10(propertiesList.at(9)); p10 >> stop2;
			string mismatchesStr;	// Property Col11: error info
			mismatchesStr = propertiesList.at(10);

			// mismatch pair<index of edge from the contained read, position>
			vector<pair<UINT32, UINT32> > *mismatchesInput = new vector<pair<UINT32, UINT32> >;
			// mismatches to list
			if ( mismatchesStr != "NA") {
				// loop mismatches
				std::stringstream mismatches_ss(mismatchesStr);
				while (getline(mismatches_ss, element, ':'))
				{
					std::istringstream element_ss(element);
					UINT32 mismatchPosition;
					char sourceCharacter, destinationCharacter;
					element_ss >> mismatchPosition;
					element_ss >> sourceCharacter;
					element_ss >> destinationCharacter;
					mismatchesInput->push_back(make_pair(0, mismatchPosition));	// simple edge, then index of edge=0

				}
			}

			// get overlap offset
			// Example edge list:
			// 0 = u<-----------<v		reverse of u to reverse of v
			// 1 = u<----------->v		reverse of u to forward of v
			// 2 = u>-----------<v		forward of u to reverse of v
			// 3 = u>----------->v		forward of u to forward of v
			//1	2   2,34,0,0,35,1,34,35,0,33,NA
			//2	3   0,33,0,0,35,2,34,35,0,32,NA
			//3	4	3,34,1,1,35,1,34,35,0,33,1CA

			// overlap offset
			UINT32 overlapOffset;
			overlapOffset = start1;	// correct, but not ready yet
			// Insert an edge
			Read *read1, *read2;
			read1 = dataSet->getReadFromID(source);
			read2 = dataSet->getReadFromID(destination);
			insertEdge(read1,read2,orientation,overlapOffset,mismatchesInput);	// insert edge
		}
	}
	filePointer.close();

	CLOCKSTOP;
}


//=============================================================================
// Insert an edge in the overlap graph.
//=============================================================================
void OverlapGraph::insertEdge(Edge * edge)
{

	UINT64 ID = edge->getSourceRead()->getReadNumber();
	if(graph->at(ID)->empty())
		numberOfNodes++;
	graph->at(ID)->push_back(edge);
	numberOfEdges++;
	updateReadLocations(edge);
}


//=============================================================================
// Insert an edge in the graph.
//=============================================================================
void OverlapGraph::insertEdge(Read *read1, Read *read2, UINT8 orient, UINT32 overlapOffset, vector<pair<UINT32, UINT32> > *mismatchesInput)
{
	// Forward edge insert
	Edge * edge1 = new Edge(read1,read2,orient,overlapOffset, mismatchesInput);

	// Reverse edge insert
	// 1. Set the overlap offset accordingly for the reverse edge. Note that read lengths are different.
	UINT32 overlapOffsetReverse = read2->getReadLength() + overlapOffset - read1->getReadLength();

	// 2. Get reverse mismatch index/positions
	vector<pair<UINT32, UINT32> > *reverseMismatchesInput = new vector<pair<UINT32, UINT32> >;
	UINT32 numContained = 0;	// there is no contained read when a new edge is created
	getReverseMismatches(mismatchesInput, numContained, overlapOffset, 
			read2->getReadLength(), reverseMismatchesInput);

	// If read lengths are the same. Then the reverse edge has the same overlap offset.
	Edge * edge2 = new Edge(read2,read1,twinEdgeOrientation(orient),
			overlapOffsetReverse,reverseMismatchesInput);

	edge1->setReverseEdge(edge2);	// Set the reverse edge pointer.
	edge2->setReverseEdge(edge1);	// Set the reverse edge pointer.
	insertEdge(edge1);	// Insert the edge in the overlap graph.
	insertEdge(edge2);	// Insert the edge in the overlap graph.
}


//=============================================================================
// Get reverse mismatches
// Ex) calculate reverseMismatchPosition (5AC -> 8CA)
// 0123456789
// ACGTTAGTTA
//     |x|||||
//     TCGTTACAAG
//     9876543210
// reverseMismatchPosition = overlapOffset(4) + Read2Length(10) - mismatchPosition(5) - 1
//=============================================================================
void OverlapGraph::getReverseMismatches(const vector<pair<UINT32, UINT32> > *mismatchesInput, 
		const UINT32 & numberOfContained, const UINT32 & overlapOffset, const UINT32 & read2Length, 
		vector<pair<UINT32, UINT32> > *reverseMismatchesInput)
{
	UINT32 mismatchIndex, reverseMismatchIndex, mismatchPosition, reverseMismatchPosition;
	for(UINT64 i = 0; i < mismatchesInput->size(); i++) {
		mismatchIndex = mismatchesInput->at(i).first;
		mismatchPosition = mismatchesInput->at(i).second;

		// reverseMismatchIndex = numberOfContained - mismatchIndex
		// exception handling
		if (numberOfContained < mismatchIndex ) {
			MYEXIT("** Error: numberOfContained="+to_string(numberOfContained)+
					" - mismatchIndex="+to_string(mismatchIndex) + "< 0");
		}
		reverseMismatchIndex = numberOfContained - mismatchIndex;

		// reverseMismatchPosition = overlapOffset + Read2Length - mismatchPosition - 1
		// exception handling
		if ( overlapOffset + read2Length < mismatchPosition + 1 ) {
			MYEXIT("** Error: overlapOffset="+to_string(overlapOffset)+
					" + read2Length="+to_string(read2Length)+"mismatchPosition-1"+
					to_string(mismatchPosition-1));
		}
		reverseMismatchPosition = overlapOffset + read2Length - mismatchPosition - 1;
		reverseMismatchesInput->push_back(make_pair(reverseMismatchIndex, reverseMismatchPosition));
	}
}


//=============================================================================
// Orientation of a reverse edge;
// Twin edge of Orientation 0 = <-------< is Orientation 3 = >------->
// Twin edge of Orientation 1 = <-------> is Orientation 1 = <------->
// Twin edge of Orientation 2 = >-------< is Orientation 2 = >-------<
// Twin edge of Orientation 3 = >-------> is Orientation 0 = <-------<
//=============================================================================
UINT8 OverlapGraph::twinEdgeOrientation(const UINT8 & orientation)
{
	assert(orientation < 4);
	switch (orientation) {
		case 0:
			return 3;
		case 1:
			return 1;
		case 2:
			return 2;
		case 3:
			return 0;
		default:
			MYEXIT("Unsupported edge orientation.")
	}
	return 4;

}


//=============================================================================
// Update location of reads for the new edge.
// The new edge may contain some reads. 
// We need to update the location information of all such reads.
//=============================================================================
void OverlapGraph::updateReadLocations(Edge *edge)
{
	UINT64 distance = 0;
	for(UINT64 i = 0; i < edge->getListOfReads()->size(); i++) 	// For each read in the edge
	{
		distance += edge->getListOfOverlapOffsets()->at(i);	// Distance of the read in the edge.
		Read *read = dataSet->getReadFromID(edge->getListOfReads()->at(i));	// Get the read object.
		if(edge->getListOfOrientations()->at(i) == 1)	// Orientation 1 means that the forward string of the read is contained in this edge.
		{
			read->getListOfEdgesForward()->push_back(edge);	// Insert the current edge in the list of forward edges.
			read->getLocationOnEdgeForward()->push_back(distance);	// Also insert the distance within the edge.
			read->getListOfEdgesForward()->resize(read->getListOfEdgesForward()->size());
			read->getLocationOnEdgeForward()->resize(read->getLocationOnEdgeForward()->size());
		}
		else	// Orientation 0 means that the reverse string of the read is contained in this edge.
		{
			read->getListOfEdgesReverse()->push_back(edge);	// Insert the current edge in the list of reverser edges.
			read->getLocationOnEdgeReverse()->push_back(distance);	// Also insert the distance withing the edge.
			read->getListOfEdgesReverse()->resize(read->getListOfEdgesReverse()->size());
			read->getLocationOnEdgeReverse()->resize(read->getLocationOnEdgeReverse()->size());
		}
	}
}


//=============================================================================
// For each node in the graph, 
// sort all its incident edges according to destination read ID.
//=============================================================================
void OverlapGraph::sortEdges()
{
	for(UINT64 i = 1; i < graph->size(); i++) {
		if(!graph->at(i)->empty())
			sort(graph->at(i)->begin(), graph->at(i)->end(), compareEdgeID);
	}
}


//=============================================================================
// Contract composite paths in the overlap graph.
// u*-------->v>---------*w  => u*--------------------*w
// u*--------<v<---------*w  => u*--------------------*w
//=============================================================================
UINT64 OverlapGraph::contractCompositeEdges(void)
{
	CLOCKSTART;
	UINT64 counter(0);
	for(UINT64 index = 1 ; index < graph->size(); index++)
	{
		if(graph->at(index)->size() == 2) // Check if the node has only two edges.
		{
			Edge *edge1 = graph->at(index)->at(0);  // First edge.
			Edge *edge2 = graph->at(index)->at(1);  // Second Edge.
			{
				// One incoming edge and one outgoing edge.
				if( matchEdgeType(edge1->getReverseEdge(), edge2) && 
						edge1->getSourceRead() != edge1->getDestinationRead()) 
				{
					mergeEdges(edge1->getReverseEdge(),edge2);	// Merge the edges.
					removeEdge(edge1);
					removeEdge(edge2);
					counter++;	// Counter how many edges merged.
				}
			}
		}

	}
	FILE_LOG(logINFO) << setw(10) << counter << " composite Edges merged." << endl;
	CLOCKSTOP;
	return counter;
}


//=============================================================================
// Merge two edges in the overlap graph.
//=============================================================================
void OverlapGraph::mergeEdges(Edge *edge1, Edge *edge2)
{
	UINT32 mismatchIndex, mismatchPosition;
	Read *read1 = edge1->getSourceRead();
	Read *read2 = edge2->getDestinationRead();

	// Orientation
	UINT8 orientationForward = mergedEdgeOrientation(edge1,edge2);
	UINT8 orientationReverse = twinEdgeOrientation(orientationForward);

	// overlap offset
	UINT32 overlapOffsetForward = edge1->getOverlapOffset() + edge2->getOverlapOffset();
	UINT32 overlapOffsetReverse = edge2->getReverseEdge()->getOverlapOffset() + 
		edge1->getReverseEdge()->getOverlapOffset();

	// forward mismatch positions should be merged of two mismatch positions vectors for the two edges
	vector<pair<UINT32, UINT32> > * mismatchesForward = new vector<pair<UINT32, UINT32> >;

	// from edge1
	for (UINT32 i = 0; i < edge1->getMismatches()->size(); i++) {
		// mismatch index for the edge 2 is going to be increased by the number of contained reads
		mismatchIndex = edge1->getMismatches()->at(i).first;
		mismatchPosition = edge1->getMismatches()->at(i).second;
		mismatchesForward->push_back(make_pair(mismatchIndex, mismatchPosition));
	}
	// from edge2
	for (UINT32 i = 0; i < edge2->getMismatches()->size(); i++) {
		// mismatch index for the edge 2 is going to be increased by the number of contained reads
		mismatchIndex = edge1->getListOfReads()->size() + 1 + edge2->getMismatches()->at(i).first;
		mismatchPosition = edge1->getOverlapOffset() + edge2->getMismatches()->at(i).second;
		mismatchesForward->push_back(make_pair(mismatchIndex, mismatchPosition));
	}

	// list of reads, offsets, and orientations
	vector<UINT64> * listReadsForward = new vector<UINT64>;
	vector<UINT32> * listOverlapOffsetsForward= new vector<UINT32>;
	vector<UINT8> * listOrientationsForward = new vector<UINT8>;

	// Merge the lists from the two edges.
	mergeList(edge1, edge2, listReadsForward, listOverlapOffsetsForward, listOrientationsForward); 

	// Make the forward edge
	Edge *edgeForward = new Edge(read1,read2,orientationForward, overlapOffsetForward, mismatchesForward, listReadsForward, listOverlapOffsetsForward, listOrientationsForward); // New forward edge.

	// reverse mismatch indexes and positions
	vector<pair<UINT32, UINT32> > * mismatchesReverse = new vector<pair<UINT32, UINT32> >;
	getReverseMismatches(mismatchesForward, listReadsForward->size(), overlapOffsetForward, read2->getReadLength(), mismatchesReverse);

	vector<UINT64> * listReadsReverse = new vector<UINT64>;
	vector<UINT32> * listOverlapOffsetsReverse= new vector<UINT32>;
	vector<UINT8> * listOrientationsReverse = new vector<UINT8>;

	// Merge the lists from the two reverse edges.
	mergeList(edge2->getReverseEdge(),edge1->getReverseEdge(), listReadsReverse, listOverlapOffsetsReverse,listOrientationsReverse);

	// Make the reverse edge
	Edge *edgeReverse = new Edge(read2, read1, orientationReverse, overlapOffsetReverse, mismatchesReverse, listReadsReverse, listOverlapOffsetsReverse, listOrientationsReverse); // New reverse edge.

	edgeForward->setReverseEdge(edgeReverse);
	edgeReverse->setReverseEdge(edgeForward);

	insertEdge(edgeForward);
	insertEdge(edgeReverse);

	// edge and position check
	for (UINT32 i = 0; i < edgeForward->getMismatches()->size(); i++)
	{
		// mismatch index for the edge 2 is going to be increased by the number of contained reads
		mismatchIndex = edgeForward->getMismatches()->at(i).first;
		mismatchPosition = edgeForward->getMismatches()->at(i).second;
		if (mismatchPosition >= edgeForward->getEdgeLength()) {
			FILE_LOG(logERROR) << "mergeEdges!" << endl;
			FILE_LOG(logERROR) << "mismatchPosition = " << mismatchPosition 
				<< ">= getEdgeLength()" << endl;
			MYEXIT("Error! edgeForward");
		}
	}

	// edge and position check
	for (UINT32 i = 0; i < edgeReverse->getMismatches()->size(); i++)
	{
		// mismatch index for the edge 2 is going to be increased by the number of contained reads
		mismatchIndex = edgeReverse->getMismatches()->at(i).first;
		mismatchPosition = edgeReverse->getMismatches()->at(i).second;
		if (mismatchPosition >= edgeReverse->getEdgeLength()) {
			FILE_LOG(logERROR) << "mergeEdges!" << endl;
			FILE_LOG(logERROR) << "mismatchPosition = " << mismatchPosition 
				<< ">= getEdgeLength()" << endl;
			MYEXIT("Error! edgeReverse!");
		}
	}
}


//=============================================================================
// Merge the list of reads, list of overlap offsets and list of orientations of two edges.
//=============================================================================
void OverlapGraph::mergeList(const Edge *edge1, const Edge *edge2, vector<UINT64> *listReads, vector<UINT32> *listOverlapOffsets, vector<UINT8> *listOrientations)
{
	UINT64 sum = 0;

	// Take the list from edge1.
	for(UINT64 i = 0; i < edge1->getListOfOrientations()->size(); i++)	
	{
		listReads->push_back(edge1->getListOfReads()->at(i));
		listOverlapOffsets->push_back(edge1->getListOfOverlapOffsets()->at(i));
		listOrientations->push_back(edge1->getListOfOrientations()->at(i));
		sum += edge1->getListOfOverlapOffsets()->at(i);
	}
	// Insert the common node of the two edges
	listReads->push_back(edge1->getDestinationRead()->getReadNumber()); 	
	// Get the overlap offset.
	listOverlapOffsets->push_back(edge1->getOverlapOffset() - sum);	

	// Orientation of the common node. 
	// Depends on the orientation of the edges.
	if(edge1->getOrientation() == 1 || edge1->getOrientation() == 3)	
		listOrientations->push_back(1);
	else
		listOrientations->push_back(0);

	// take the list from edge2.
	for(UINT64 i = 0; i < edge2->getListOfOrientations()->size(); i++){
		listReads->push_back(edge2->getListOfReads()->at(i));
		listOverlapOffsets->push_back(edge2->getListOfOverlapOffsets()->at(i));
		listOrientations->push_back(edge2->getListOfOrientations()->at(i));
	}
}


//=============================================================================
// Orientation of the merged edge.
// e1(u,v) e2(v,w)
// Orientation e1 0 = u<-------<v		Orientation e2 0 = v<-------<w
// Orientation e1 1 = u<------->v		Orientation e2 1 = v<------->w
// Orientation e1 2 = u>-------<v		Orientation e2 2 = v>-------<w
// Orientation e1 3 = u>------->v		Orientation e2 3 = v>------->w
//
// 0 + 0 = u<-------<w
// 0 + 1 = u<------->w
//...................
//
//=============================================================================
UINT8 OverlapGraph::mergedEdgeOrientation(const Edge *edge1, const Edge *edge2)
{
	UINT8 or1 = edge1->getOrientation(), or2 = edge2->getOrientation(),returnValue;
	if(or1 == 0 && or2 == 0)
		returnValue = 0;
	else if(or1 == 0 && or2 == 1)
		returnValue = 1;
	else if(or1 == 1 && or2 == 2)
		returnValue = 0;
	else if(or1 == 1 && or2 == 3)
		returnValue = 1;
	else if(or1 == 2 && or2 == 0)
		returnValue = 2;
	else if(or1 == 2 && or2 == 1)
		returnValue = 3;
	else if(or1 == 3 && or2 == 2)
		returnValue = 2;
	else if(or1 == 3 && or2 == 3)
		returnValue = 3;
	else
	{
		FILE_LOG(logERROR)<<(int)or1<<" "<<(int)or2<<endl;
		MYEXIT("Unable to merge.")
	}
	return returnValue;
}

//=============================================================================
// Remove an edge from the overlap graph.
//=============================================================================
void OverlapGraph::removeEdge(Edge *edge, bool save_for_contig)
{
	// If the current edge contains some reads. We have to update their location formation.
	removeReadLocations(edge);
	removeReadLocations(edge->getReverseEdge());	// Same for the reverse edge.

	UINT64 ID1 	= edge->getSourceRead()->getReadNumber(); 
	UINT64 ID2 	= edge->getDestinationRead()->getReadNumber();
	Edge *twinEdge 	= edge->getReverseEdge();

	for(UINT64 i = 0; i< graph->at(ID2)->size(); i++) // Delete the twin edge first.
	{
		if(graph->at(ID2)->at(i) == twinEdge)
		{
			if (!save_for_contig)
				delete graph->at(ID2)->at(i);
			else{
				deletedEdges->push_back(graph->at(ID2)->at(i));
				FILE_LOG(logDEBUG) << "Insert deleted edge " << *twinEdge << " to vector" << endl;
			}
			graph->at(ID2)->at(i) = graph->at(ID2)->at(graph->at(ID2)->size()-1);
			graph->at(ID2)->pop_back();
			if(graph->at(ID2)->empty())
				numberOfNodes--;
			numberOfEdges--;
			// graph->shrink_to_fit(); // didn't work well to release
			break;
		}
	}
	for(UINT64 i = 0; i< graph->at(ID1)->size(); i++) // Delete the edge then.
	{
		if(graph->at(ID1)->at(i) == edge)
		{
			if (!save_for_contig)
				delete graph->at(ID1)->at(i);
			else{
				deletedEdges->push_back(graph->at(ID1)->at(i));
				FILE_LOG(logDEBUG) << "Insert deleted edge " << *twinEdge << " to vector" << endl;
			}
			graph->at(ID1)->at(i) = graph->at(ID1)->at(graph->at(ID1)->size()-1);
			graph->at(ID1)->pop_back();
			if(graph->at(ID1)->empty())
				numberOfNodes--;
			numberOfEdges--;
			// graph->shrink_to_fit(); // didn't work well to release
			break;
		}
	}
}


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  breakForwardEdge
 *  Description:  Break an edge at a specified link, only the forward edge
 * =====================================================================================
 */
vector<Edge*> OverlapGraph::breakForwardEdge(Edge *edge, UINT64 link)
{
	vector<Edge*> sub_edges;
	/* If the edge is simple, then simply delete it from the graph 
	 * If the edge is composite, insert two new edges, and then delete the current edge */
	if (edge->getListOfReads()->size() != 0){
		vector<UINT64> * list_of_readIDs = edge->getListOfReads();
		UINT64 num_reads = list_of_readIDs->size();

		assert(link <= num_reads);
		vector<UINT8> * list_of_orients = edge->getListOfOrientations();
		vector<UINT32> * list_of_overlap_offsets = edge->getListOfOverlapOffsets();
		vector<pair<UINT32, UINT32> > * mismatchInfo = edge->getMismatches();	// get mismaches of the edge

		/* the position is not the first link, 
		 * there will be an edge with source the same as the original source */
		if(link != 0){                   
			UINT64 ovloffset = list_of_overlap_offsets->at(0);
			Read* e1_dest_read = dataSet->getReadFromID(edge->getListOfReads()->at(link-1)); 
			UINT64 e1_orient = (edge->getOrientation() & 2) + list_of_orients->at(link-1);
			vector<pair<UINT32, UINT32> > * e1_mismatches = new vector<pair<UINT32, UINT32> >;
			/* e1 is a simple edge */
			if(link == 1){
				// e1 mismatches should have mismatchIndex=0, do not need to update the mismatch position. New mismatch position should be same.
				for (UINT32 i = 0; i < mismatchInfo->size(); i++) {
					if (mismatchInfo->at(i).first == 0) {
						e1_mismatches->push_back(mismatchInfo->at(i));
						// exception handling - mismatch position should be smaller than edge length
						if (mismatchInfo->at(i).second >= ovloffset + e1_dest_read->getReadLength()) {
							MYEXIT("** Error: e1-simple edge: mismatch position should be smaller than edge length.");
						}
					}
				}
				Edge * e1 = new Edge(edge->getSourceRead(), e1_dest_read, e1_orient, ovloffset, e1_mismatches);
				sub_edges.push_back(e1);
				FILE_LOG(logDEBUG1) << "First sub edge is " << *e1 << endl;
			}
			/* e1 is a composite edge */
			else{
				vector<UINT64> * e1_list_reads = new vector<UINT64>;
				vector<UINT32> * e1_list_ovloffsets = new vector<UINT32>;
				vector<UINT8> * e1_list_orients = new vector<UINT8>;
				UINT64 i = 0;
				for(i = 0; i < (link-1); i++){
					e1_list_reads->push_back(list_of_readIDs->at(i));
					e1_list_ovloffsets->push_back(list_of_overlap_offsets->at(i));
					e1_list_orients->push_back(list_of_orients->at(i));
					ovloffset += list_of_overlap_offsets->at(i+1);
				}
				// e1 mismatches should have mismatchIndex<=(link-1), do not need to update the mismatch position. New mismatch position should be same.
				for (UINT64 i = 0; i < mismatchInfo->size(); i++) {
					if (mismatchInfo->at(i).first <= (link-1)) {
						e1_mismatches->push_back(mismatchInfo->at(i));
						// exception handling - mismatch position should be smaller than edge length
						if (mismatchInfo->at(i).second >= ovloffset + e1_dest_read->getReadLength()) {
							MYEXIT("** Error: e1-composite edge: mismatch position should be smaller than edge length.");
						}
					}
				}
				//e1_list_reads->resize(); e1_list_ovloffsets->resize(); e1_list_orients->resize();
				Edge * e1 = new Edge(edge->getSourceRead(), e1_dest_read, e1_orient, ovloffset, e1_mismatches, e1_list_reads, e1_list_ovloffsets, e1_list_orients);
				sub_edges.push_back(e1);
				FILE_LOG(logDEBUG1) << "First sub edge is " << *e1 << endl;
			}
		}
		if(link != num_reads){          /* the position is not the last link, there will be an edge with destination the same as the original destination */
			UINT32 mismatchIndex, mismatchPosition;
			UINT64 ovloffset = edge->getOverlapOffset(); /* last overlap offset */
			for(UINT64 i = 0; i < num_reads; i++){
				ovloffset -= list_of_overlap_offsets->at(i);
			}
			Read* e2_source_read = dataSet->getReadFromID(edge->getListOfReads()->at(link)); /* destination read for e2 */
			UINT64 e2_orient = (edge->getOrientation() & 1) + (list_of_orients->at(link)  << 1); /* orientation */
			vector<pair<UINT32, UINT32> > * e2_mismatches = new vector<pair<UINT32, UINT32> >;
			/* e2 is a simple edge */
			if(link == (num_reads-1)){
				// e2 mismatches should have mismatchIndex=link+1, update the index and mismatch position.
				for (UINT64 i = 0; i < mismatchInfo->size(); i++) {
					if (mismatchInfo->at(i).first == link+1) {
						// mismatchIndex should be 0 as it is a new simple edge
						mismatchIndex = 0;
						// new mismatch position = old mismatch position - list_of_overlap_offsets->at(num_reads-1)
						// exception handling: mismatch position should be >=0
						if (mismatchInfo->at(i).second < list_of_overlap_offsets->at(num_reads-1)) {
							MYEXIT("** Error: e2-simple edge: mismatchInfo->at(i).second("+to_string(mismatchInfo->at(i).second)+") - list_of_overlap_offsets->at(num_reads)("+to_string(list_of_overlap_offsets->at(num_reads-1))+") < 0 !");
						}
						mismatchPosition = mismatchInfo->at(i).second - list_of_overlap_offsets->at(num_reads-1);
						// exception handling - mismatch position should be smaller than edge length
						if (mismatchPosition >= ovloffset + edge->getDestinationRead()->getReadLength()) {
							MYEXIT("** Error: e2-simple edge: mismatch position should be smaller than edge length.");
						}
						e2_mismatches->push_back(make_pair(mismatchIndex, mismatchPosition));
					}
				}
				Edge *e2 = new Edge(e2_source_read, edge->getDestinationRead(), e2_orient, ovloffset, e2_mismatches);
				sub_edges.push_back(e2);
				FILE_LOG(logDEBUG1) << "Second sub edge is " << *e2 << endl;
			}
			/* e2 is a composite edge */
			else{
				vector<UINT64> * e2_list_reads = new vector<UINT64>;
				vector<UINT32> * e2_list_ovloffsets = new vector<UINT32>;
				vector<UINT8> * e2_list_orients = new vector<UINT8>;
				UINT64 i = 0;
				for(i = link+1; i < num_reads; i++){
					e2_list_reads->push_back(list_of_readIDs->at(i));
					e2_list_ovloffsets->push_back(list_of_overlap_offsets->at(i));
					e2_list_orients->push_back(list_of_orients->at(i));
					ovloffset += list_of_overlap_offsets->at(i);
				}
				// e2 mismatches should have mismatchIndex > link, update the index and mismatch position.
				for (UINT32 i = 0; i < mismatchInfo->size(); i++) {
					if (mismatchInfo->at(i).first > link) {
						mismatchIndex = mismatchInfo->at(i).first - (link+1);
						// new mismatch position = old mismatch position - edge->getOverlapOffset() + ovloffset
						// exception handling: mismatch position should be >=0
						if (mismatchInfo->at(i).second < list_of_overlap_offsets->at(num_reads-1)) {
							MYEXIT("** Error: e2-composite edge: mismatchInfo->at(i).second("+to_string(mismatchInfo->at(i).second)+") - list_of_overlap_offsets->at(num_reads)("+to_string(list_of_overlap_offsets->at(num_reads-1))+") < 0 !");
						}
						mismatchPosition = mismatchInfo->at(i).second - edge->getOverlapOffset() + ovloffset;
						// exception handling - mismatch position should be smaller than edge length
						if (mismatchPosition >= ovloffset + edge->getDestinationRead()->getReadLength()) {
							MYEXIT("** Error: e2-composite edge: mismatch position should be smaller than edge length.");
						}
						e2_mismatches->push_back(make_pair(mismatchIndex, mismatchPosition));
					}
				}
				//e2_list_reads->resize(); e2_list_ovloffsets->resize(); e2_list_orients->resize();
				Edge *e2 = new Edge(e2_source_read, edge->getDestinationRead(), e2_orient, ovloffset, e2_mismatches, e2_list_reads, e2_list_ovloffsets, e2_list_orients);
				sub_edges.push_back(e2);
				FILE_LOG(logDEBUG1) << "Second sub edge is " << *e2 << endl;
			}
		}
	}
	return sub_edges;
}


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  breakEdge
 *  Description:  break a given edge into (at most) 2 bi-directed edges.
 *  First create sub-edges after the specified link is taken out, both forward and reverse;
 *  then insert these sub-edges in the graph, then remove the original edge.
 * =====================================================================================
 */
void OverlapGraph::breakEdge(Edge *edge, UINT64 link)
{
	if(edge->getListOfReads()->size() != 0)
	{
		FILE_LOG(logDEBUG1) << "\tbreak composite edge" << endl;
		vector<Edge*> forward_sub_edges = breakForwardEdge(edge, link);           /* insert new forward edges */
		vector<Edge*> backward_sub_edges = breakForwardEdge(edge->getReverseEdge(), edge->getListOfReads()->size() - link); /* insert new twin edges */
		UINT64 num_edges = forward_sub_edges.size();
		for(UINT64 i = 0; i < num_edges; i++) {
			// set twin edges
			forward_sub_edges.at(i)->setReverseEdge(backward_sub_edges.at(num_edges-i-1));
			backward_sub_edges.at(num_edges-i-1)->setReverseEdge(forward_sub_edges.at(i));
			// Insert them into the graph
			insertEdge(forward_sub_edges.at(i));
			insertEdge(backward_sub_edges.at(num_edges-i-1));
		}
	}
	else{
		FILE_LOG(logDEBUG1) << "\tbreak simple edge" << endl;
	}
	removeEdge(edge);                       /* remove original edge and its twin edge */
}


//=============================================================================
// Remove read mapping information of the current edge.
// This function is called when an edge is removed.
//=============================================================================
void OverlapGraph::removeReadLocations(Edge *edge)
{
	for(UINT64 i = 0; i < edge->getListOfReads()->size(); i++) 	// For each read in this edge.
	{
		Read *read = dataSet->getReadFromID(edge->getListOfReads()->at(i)); 	// Get the read object.
		for(UINT64 j = 0; j < read->getListOfEdgesForward()->size(); j++)  	// Check the list of edges that contain forward of this read.
		{
			if(read->getListOfEdgesForward()->at(j) == edge)	// Remove the current edge from the list.
			{
				read->getListOfEdgesForward()->at(j) = read->getListOfEdgesForward()->at(read->getListOfEdgesForward()->size()-1);
				read->getLocationOnEdgeForward()->at(j) = read->getLocationOnEdgeForward()->at(read->getLocationOnEdgeForward()->size()-1);

				read->getListOfEdgesForward()->pop_back();
				read->getLocationOnEdgeForward()->pop_back();

				read->getListOfEdgesForward()->resize(read->getListOfEdgesForward()->size());
				read->getLocationOnEdgeForward()->resize(read->getLocationOnEdgeForward()->size());
			}
		}

		for(UINT64 j = 0; j < read->getListOfEdgesReverse()->size(); j++) 	// Check the list of edges that contain reverse of this read.
		{
			if(read->getListOfEdgesReverse()->at(j) == edge) 	// Remove the current edge from the list.
			{
				read->getListOfEdgesReverse()->at(j) = read->getListOfEdgesReverse()->at(read->getListOfEdgesReverse()->size()-1);
				read->getLocationOnEdgeReverse()->at(j) = read->getLocationOnEdgeReverse()->at(read->getLocationOnEdgeReverse()->size()-1);

				read->getListOfEdgesReverse()->pop_back();
				read->getLocationOnEdgeReverse()->pop_back();

				read->getListOfEdgesReverse()->resize(read->getListOfEdgesReverse()->size());
				read->getLocationOnEdgeReverse()->resize(read->getLocationOnEdgeReverse()->size());
			}
		}
	}
}


//=============================================================================
// Remove nodes with all simple edges and all same arrow type
//
// A node is all incoming edges or all outgoing edges is called a dead end node.
// While traversing the graph if we // enter such node, there is no way we can
// go out. So we remove such nodes from the graph. To remove the node all of
// its edges must be simple edges or very short edges (less than 10 read in it).
//=============================================================================
UINT64 OverlapGraph::removeDeadEndNodes(void)
{
	CLOCKSTART;
	vector <UINT64> listOfNodesToBeRemoved; // for saving nodes that should be deleted
	UINT64 edgesRemoved = 0;
	for(UINT64 i = 1; i < graph->size(); i++) // For each read.
	{
		if(!graph->at(i)->empty())	// If the read has some edges.
		{
			bool isDeadEnd = true;	// flag for dead end edge
			UINT64 inEdge = 0; 	// number of incoming edges to this node
			UINT64 outEdge = 0; 	// number of outgoing edges from this node

			for(UINT64 j=0; j < graph->at(i)->size(); j++) // For each edge
			{
				Edge * edge = graph->at(i)->at(j);
				// Break case:
				// 1. if composite edge is more than minReadsCountInEdgeToBeNotDeadEnd (deafult: 10)
				// 2. if composite edge is longer than minEdgeLengthToBeNotDeadEnd (default: 500)
				// 3. if the edge is loop for the current node
				// Then flag=1 and exit the loop

				// Case 1:
				if(edge->getListOfReads()->size() >= minReadsCountInEdgeToBeNotDeadEnd) {
					isDeadEnd = false;
					break;
				}
				// Case 2:
				if(edge->getEdgeLength() >= minEdgeLengthToBeNotDeadEnd) {
					isDeadEnd = false;
					break;
				}
				// Case 3:
				if(edge->getSourceRead()->getReadNumber() == edge->getDestinationRead()->getReadNumber())
				{
					isDeadEnd = false;
					break;
				}

				if(edge->getOrientation() == 0 || edge->getOrientation() == 1)
					inEdge++;	// the number of incoming edges to this node
				else
					outEdge++;	// the number of outgoing edges to this node
			}
			// if all edges are incoming or outgoing AND has less than 10 reads, this node is marked to be removed?
			// This node does not have any composite edge with more than 10 reads in it.
			if( isDeadEnd ) // If not break case
			{
				if( (inEdge > 0 && outEdge == 0) || (inEdge == 0 && outEdge > 0)) // only one type of simple edges
				{
					listOfNodesToBeRemoved.push_back(i);
				}
			}
		}
	}
	FILE_LOG(logDEBUG)<< "Dead-end nodes detected: " << listOfNodesToBeRemoved.size() << endl;

	//  in below actually to remove the marked deadend nodes and all their edges.
	vector <Edge *> listOfEdges;
	for(UINT64 i = 0 ; i < listOfNodesToBeRemoved.size(); i++)
	{
		listOfEdges.clear();
		if(!graph->at(listOfNodesToBeRemoved.at(i))->empty())   // If the read has some edges.
		{
			edgesRemoved += graph->at(listOfNodesToBeRemoved.at(i))->size();
			for(UINT64 j=0; j < graph->at(listOfNodesToBeRemoved.at(i))->size(); j++) // For each edge
			{
				Edge* e = graph->at(listOfNodesToBeRemoved.at(i))->at(j);
				// Print "warning message when the dead-end edge has nonzero flow, this will make flow unbalanced
				if( e->flow > 0 )
				{
					FILE_LOG(logDEBUG) << "Dead-end edge to remove has flow " << e->flow << ": " << *e << endl;
				}
				listOfEdges.push_back(e);
			}
			for(UINT64 j = 0; j< listOfEdges.size(); j++)
			{
				removeEdge(listOfEdges.at(j));	// Remove all the edges of the current node.
			}
		}
	}
	if (listOfNodesToBeRemoved.size() > 0){
		FILE_LOG(logINFO)<< "Dead-end nodes removed: " << listOfNodesToBeRemoved.size() << endl;
		FILE_LOG(logINFO)<< "Dead-end edges removed: " << edgesRemoved << endl;
	}
	CLOCKSTOP;
	return listOfNodesToBeRemoved.size();
}


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  removeShortBranches
 *  Description:  After flow analysis, at late stage of graph simplification.
 *  Now only look at nodes with 1 incident edge, if this edge is much shorter comparing
 *  to other edges incident to its neighbor, then remove this relatively short branch.
 * =====================================================================================
 */
UINT64 OverlapGraph::removeShortBranches(void)
{
	CLOCKSTART;
	if(this->flowComputed == false)
	{
		FILE_LOG(logINFO) << "Flow not computed, won't remove short branches." << endl;
		return 0;
	}
	vector <UINT64> listOfNodesToBeRemoved; // list of nodes that should be deleted
	UINT64 edgesRemoved = 0;
	vector<UINT16> neighbor_long_brlens;     /* longest branch lengths at nodes, 1 for in edges, 1 for out edges */
	typedef vector<UINT16> LongBrLens;
	map<UINT64, LongBrLens> long_brlens_map; /* map from read number to length vector of length 2 */
	for(UINT64 i = 1; i < graph->size(); i++) // For each read.
	{
		if(graph->at(i)->size()==1 && graph->at(i)->at(0)->getDestinationRead()->getReadNumber()!=i)     /* If this read has exactly 1 incident edge, and this edge is not a loop */
		{
			Edge* one_edge = graph->at(i)->at(0)->getReverseEdge(); /* The incident edge, going out from its only neighbor */
			UINT64 neighbor = one_edge->getSourceRead()->getReadNumber();
			UINT64 neighbor_degree = graph->at(neighbor)->size();
			if(neighbor_degree > 1){ /* If neighbor has more edges besides the "short branch" */
				UINT64 one_length = one_edge->getOverlapOffset();
				UINT16 in_out;
				if(one_edge->getOrientation() == 0 || one_edge->getOrientation() == 1)
					in_out = 0;
				else
					in_out = 1;
				FILE_LOG(logDEBUG1) << "Short branch from " << i << " to " << neighbor << " with orientation " << in_out << " and length " << one_length << endl;
				if(long_brlens_map.count(neighbor)==0){
					FILE_LOG(logDEBUG1) << "Now look for the longest branches at node " << neighbor << endl;
					LongBrLens long_brlens;
					long_brlens.push_back(0);
					long_brlens.push_back(0);
					long_brlens.at(in_out) = one_length;
					/* Find the longest branches at neighbor in both directions */
					for(UINT64 j = 0; j < neighbor_degree; j++){
						Edge* e = graph->at(neighbor)->at(j);
						UINT16 direction; 
						if(e->getOrientation() == 0 || e->getOrientation() == 1)
							direction = 0;
						else
							direction = 1;
						if(e->getOverlapOffset() > long_brlens.at(direction))
							long_brlens.at(direction) = e->getOverlapOffset();

					}
					long_brlens_map[neighbor] = long_brlens;
				}
				if(one_length * minFoldToBeShortBranch < long_brlens_map.at(neighbor).at(in_out)){
					listOfNodesToBeRemoved.push_back(i);
					FILE_LOG(logDEBUG1) << "Delete this edge, length: " << one_length << " and " << long_brlens_map.at(neighbor).at(in_out) << endl;
				}
			}
		}
	}
	//  in below actually to remove the marked deadend nodes and all their edges.
	vector <Edge *> listOfEdges;
	for(UINT64 i = 0 ; i < listOfNodesToBeRemoved.size(); i++)
	{
		listOfEdges.clear();
		if(!graph->at(listOfNodesToBeRemoved.at(i))->empty())   // If the read has some edges.
		{
			edgesRemoved += graph->at(listOfNodesToBeRemoved.at(i))->size();
			for(UINT64 j=0; j < graph->at(listOfNodesToBeRemoved.at(i))->size(); j++) // For each edge
			{
				listOfEdges.push_back(graph->at(listOfNodesToBeRemoved.at(i))->at(j));
			}
			for(UINT64 j = 0; j< listOfEdges.size(); j++)
			{
				removeEdge(listOfEdges.at(j));	// Remove all the edges of the current node.
			}
		}
	}
	if(listOfNodesToBeRemoved.size() > 0){
		FILE_LOG(logINFO) << "short-branch nodes removed: " << listOfNodesToBeRemoved.size() << endl;
		FILE_LOG(logINFO) << "short-branch edges removed: " << edgesRemoved << endl;
	}
	CLOCKSTOP;
	return listOfNodesToBeRemoved.size();

}


//=============================================================================
// Simplify graph
//=============================================================================
void OverlapGraph::simplifyGraph(void)
{
	UINT64 counter = 0;
	do
	{
		counter = contractCompositeEdges();
		counter += removeSimilarEdges();
		counter += removeDeadEndNodes();
		// the three steps below requires flow to be computed
		// if simplifyGraph is called in the unitig graph, these two functions will just return.
		counter += removeShortBranches();	// Remove short branches
//		counter += reduceTrees();	// Remove trees.
		counter += reduceLoops();	// Reduce loops

	} while (counter > 0);
}


//=============================================================================
// Remove edges with similar endpoint in the overlap graph
//=============================================================================
UINT64 OverlapGraph::removeSimilarEdges(void)
{
	CLOCKSTART;
	UINT64 counter = 0;
	// pairs of edges that are found, the two lists have the same length, a pair are in the same index
	vector <Edge *> listOfEdges1; // edges to be kept
	vector <Edge *> listOfEdges2; // edges to be removed

	for(UINT64 i = 1; i < graph->size(); i++)	// For each node.
	{
		if(!graph->at(i)->empty())	// The node has some edges in the graph.
		{
			for(UINT64 j = 0; j < graph->at(i)->size(); j++)	// For all the edges.
			{
				Edge * e1 = graph->at(i)->at(j);
				UINT64 source1 = e1->getSourceRead()->getReadNumber(), destination1 = e1->getDestinationRead()->getReadNumber();
				if( source1 < destination1)
				{
					for(UINT64 k = j + 1; k < graph->at(i)->size(); k++)
					{
						Edge * e2 = graph->at(i)->at(k);
						UINT64 source2 = e2->getSourceRead()->getReadNumber(), destination2 = e2->getDestinationRead()->getReadNumber();
						if( source1 == source2 && destination1 == destination2)	// Check both edges starts and ends at same end points
						{
							if( abs((int)(e1->getOverlapOffset() - e2->getOverlapOffset())) <  (int)(e2->getOverlapOffset()/20) ) // The lengths are more than 95% similar
							{
								if(e1->getOrientation() != e2->getOrientation()){
									FILE_LOG(logDEBUG) << "Bubble edges have different orientation between " << source1 <<
										" and " << destination1 << 
										": " << (int)e1->getOrientation() << " and " << (int)e2->getOrientation() <<
										endl;
								}
								else{
									UINT64 l;
									getBaseByBaseCoverage(e1);
									getBaseByBaseCoverage(e2);
									if(e1->coverageDepth < e2->coverageDepth ||	
										(e1->coverageDepth == e2->coverageDepth && 
										 e1->getListOfReads()->size() < e2->getListOfReads()->size()))
										// Will swap the edges based on coverage depth.
									{
										Edge *temp = e1;
										e1 = e2;
										e2 = temp;
									}
									for(l= 0; l <  listOfEdges1.size(); l++)	// Already in the list.
									{
										if(listOfEdges2.at(l) == e1 || listOfEdges2.at(l) ==  e2) // check if the edges are already used.
											break;
									}
									if(l ==  listOfEdges1.size())	// Not in the list. Add it in the list.
									{
										listOfEdges1.push_back(e1);	// We will keep this edge.
										listOfEdges2.push_back(e2);	// This edge will be deleted and the flow will be moved to the first edge.
									}
								}
							}

						}
					}
				}
			}
		}
	}

	// Remove edges in listOfEdges2 and move their flow to their corresponding edge in listOfEdges1
	FILE_LOG(logDEBUG) << listOfEdges1.size()<< " edges to remove" << endl;
	for(UINT64 i = 0; i < listOfEdges1.size(); i++)
	{
		if(loglevel > 2){
			FILE_LOG(logDEBUG) << setw(10) << ++ counter << " removing edge ("<< setw(10) << listOfEdges1.at(i)->getSourceRead()->getReadNumber()<<","
				<< setw(10) << listOfEdges1.at(i)->getDestinationRead()->getReadNumber()<<") Lengths : " << setw(10)
				<< listOfEdges1.at(i)->getOverlapOffset() << " and " << setw(10) << listOfEdges2.at(i)->getOverlapOffset()
				<< " Flows: " << setw(3) << listOfEdges1.at(i)->flow << " and " << setw(3) << listOfEdges2.at(i)->flow
				<< " Reads: " << listOfEdges1.at(i)->getListOfReads()->size()
				<< " and " << listOfEdges2.at(i)->getListOfReads()->size() << endl;
		}
		listOfEdges1.at(i)->flow += listOfEdges2.at(i)->flow;	// Move the flow of the delete edge to this edge.
		listOfEdges1.at(i)->getReverseEdge()->flow += listOfEdges2.at(i)->getReverseEdge()->flow;	// Same for the reverse edge.
		removeEdge(listOfEdges2.at(i));
		counter++;
	}
	FILE_LOG(logINFO) << counter << " edges removed during bubble popping." << endl;
	CLOCKSTOP;
	return counter;
}


//=============================================================================
// This function returns the edit distance between two strings.
// Code downloaded from http://rosettacode.org/wiki/Levenshtein_distance#C.2B.2B
//
// the Levenshtein distance is a metric for measuring the amount of difference between two sequences (i.e. an edit distance).
// The Levenshtein distance between two strings is defined as the minimum number of edits needed to transform one string into the other,
// with the allowable edit operations being insertion, deletion, or substitution of a single character.
// For example, the Levenshtein distance between "kitten" and "sitting" is 3, since the following three edits change one into the other,
// and there is no way to do it with fewer than three edits
//
//=============================================================================
UINT64 OverlapGraph::calculateEditDistance(const  string & s1, const string & s2)
{
	const UINT64 m(s1.size());
	const UINT64 n(s2.size());
	if( m==0 )
		return n;
	if( n==0 )
		return m;
	UINT64 *costs = new UINT64[n + 1];
	for( UINT64 k=0; k<=n; k++ )
		costs[k] = k;

	UINT64 i = 0;
	for ( std::string::const_iterator it1 = s1.begin(); it1 != s1.end(); ++it1, ++i )
	{
		costs[0] = i+1;
		UINT64 corner = i;
		UINT64 j = 0;
		for ( std::string::const_iterator it2 = s2.begin(); it2 != s2.end(); ++it2, ++j )
		{
			UINT64 upper = costs[j+1];
			if( *it1 == *it2 )
			{
				costs[j+1] = corner;
			}
			else
			{
				UINT64 t(upper<corner?upper:corner);
				costs[j+1] = (costs[j]<t?costs[j]:t)+1;
			}
			corner = upper;
		}
	}
	UINT64 result = costs[n];
	delete [] costs;
	//cout << s1 << endl << s2 << endl << result<< endl;
	return result;
}


//=============================================================================
// Calculate the coverage depth of an edge for every basepair and then update
// the Mean and SD of coverage depth in the edge. Only consider reads that are
// unique to the edge.
// CP: Calculate the variable, coverageDepth and SD, the Edge class
//=============================================================================
void OverlapGraph::getBaseByBaseCoverage(Edge *edge)
{
	vector<UINT64> * coverageBaseByBase = new vector<UINT64>;
	// Array lenght same as the string length in the edge.
	UINT64 length = edge->getOverlapOffset() + edge->getDestinationRead()->getReadLength();
	for(UINT64 i = 0; i <=length; i++)
	{
		coverageBaseByBase->push_back(0);	// At first all the bases are covered 0 times.
	}
	UINT64 overlapOffset = 0;
	// Increment the coverage of the section that each read covers,
	// NOT counting the source read and destination read because they are shared amony multiple edges
	for(UINT64 i = 0; i < edge->getListOfReads()->size(); i++)	// For each read in the edge.
	{
		Read *read = dataSet->getReadFromID(edge->getListOfReads()->at(i));
		overlapOffset += edge->getListOfOverlapOffsets()->at(i);	// Where the current read starts in the string.
		UINT64 readLength = read->getReadLength();
		for(UINT64 j = overlapOffset; j < overlapOffset + readLength; j++)
		{
			coverageBaseByBase->at(j) += 1;	// Increase the coverage of all bases by one of the read.
		}
	}

	// clear the coverage of the section that is covered by non-unique reads that are contained by multiple edges
	overlapOffset = 0;
	for(UINT64 i = 0; i < edge->getListOfReads()->size(); i++) // Scan the reads again.
	{
		Read *read = dataSet->getReadFromID(edge->getListOfReads()->at(i));
		overlapOffset += edge->getListOfOverlapOffsets()->at(i);
		UINT64 readLength = read->getReadLength();
		if(read->getListOfEdgesForward()->size() > 1)	// Clear the bases that are covered by reads apperaing in multiple places in the graph.
		{
			for(UINT64 j = overlapOffset; j < overlapOffset + readLength; j++)
			{
				coverageBaseByBase->at(j) = 0;
			}
		}
	}
	// clear the coverage of the section that is covered by the source read, because source read is present in multiple edges
	for(UINT64 i = 0; i < edge->getSourceRead()->getReadLength(); i++)
	{
		coverageBaseByBase->at(i) = 0;
	}

	// clear the coverage of the section that is covered by the destination read, because destination read is present in multiple edges
	for(UINT64 i = 0; i < edge->getDestinationRead()->getReadLength(); i++)	// Similarly clear the bases covered by the destination read.
	{
		coverageBaseByBase->at(coverageBaseByBase->size() - 1 - i) = 0;
	}

	UINT64 sum = 0, variance=0, count = 0, mean = 0, sd = 0;

	// calculate mean and standard deviation of coverage of all bases from non-zero counts
	for(UINT64 i = 0; i < coverageBaseByBase->size(); i++)
	{
		if(coverageBaseByBase->at(i) != 0)	// Count only the non-zero values.
		{
			sum += coverageBaseByBase->at(i);
			count++;
		}
	}
	if ( count != 0 )
	{
		mean = sum/count;	// Calculate the mean.

		for(UINT64 i = 0; i < coverageBaseByBase->size(); i++)
		{
			if(coverageBaseByBase->at(i) != 0)	// Calculate the variance.
			{
				variance += (mean - coverageBaseByBase->at(i)) * (mean - coverageBaseByBase->at(i));
			}
		}
		sd = sqrt(variance/count);	// Calculate the standard deviation.
	}
	// if no base of this edge is covered by unique reads, then the mean and SD are 0
	edge->coverageDepth = mean;	// Update the mean of the current edge.
	edge->SD = sd;	// Update the standard deviation of the current edge.
	delete coverageBaseByBase;
}


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  clipBranches
 *  Description:  When a node has multiple in- or out- edges, clip the edges with small
 *  		  overlap lengths
 * =====================================================================================
 */
UINT64 OverlapGraph::clipBranches(void)
{
	CLOCKSTART;
	UINT64 num_clip_branches = 0;

	UINT64 max_in_ovl, max_out_ovl, ovl;

	for(UINT64 i = 1; i < graph->size(); i++){
		if(graph->at(i)->size() > 1){
			max_in_ovl = 0; max_out_ovl = 0;
			vector<Edge*> inEdges, outEdges;
			vector<UINT64> inOvls, outOvls;
			for(UINT64 j = 0; j < graph->at(i)->size(); j++){
				Edge* e = graph->at(i)->at(j);
				// Find the first overlap length
				if(e->getListOfReads()->empty())
					ovl = e->getSourceRead()->getReadLength() - e->getOverlapOffset();
				else
					ovl = e->getSourceRead()->getReadLength() - e->getListOfOverlapOffsets()->at(0);
				// Do not consider loop for now TODO might later
				if(e->getDestinationRead()->getReadNumber() != e->getSourceRead()->getReadNumber()){
					// In edges
					if(e->getOrientation() == 0 || e->getOrientation() == 1){
						inEdges.push_back(e);
						inOvls.push_back(ovl);
						if(ovl > max_in_ovl){
							max_in_ovl = ovl;
						}
					}
					// Out edges
					else{
						outEdges.push_back(e);
						outOvls.push_back(ovl);
						if(ovl > max_out_ovl){
							max_out_ovl = ovl;
						}
					}
				}
			}
			if(inEdges.size() > 1){
				for(UINT64 k = 0; k < inEdges.size(); k++){
					if((inOvls.at(k) + minOvlDiffToClip) < max_in_ovl){
						FILE_LOG(logDEBUG1) << "Break edge " << *(inEdges.at(k)) << " with overlap length " << inOvls.at(k) << " comparing to " << max_in_ovl << endl;
						breakEdge(inEdges.at(k),0);
						num_clip_branches++;
					}
				}
			}
			if(outEdges.size() > 1){
				for(UINT64 k = 0; k < outEdges.size(); k++){
					if((outOvls.at(k) + minOvlDiffToClip) < max_out_ovl){
						FILE_LOG(logDEBUG) << "Break edge " << *(outEdges.at(k)) << " with overlap length " << outOvls.at(k) << " comparing to " << max_out_ovl << endl;
						breakEdge(outEdges.at(k),0);
						num_clip_branches++;
					}
				}
			}
			FILE_LOG(logDEBUG) << "Node " << i << " done with clipBranches" << endl << endl;
		}
	}
	FILE_LOG(logINFO) << "Short overlap branches clipped: " << num_clip_branches << endl;
	CLOCKSTOP;
	return num_clip_branches;
}


//=============================================================================
// This function removes in-trees and out-trees.
//=============================================================================
UINT64 OverlapGraph::reduceTrees(void)
{
	if(this->flowComputed == false)
	{
		return 0;
	}
	CLOCKSTART;
	UINT64 NumOfInEdges, NumOfOutEdges, nodeMerged = 0;
	vector <Edge *> listOfInEdges, listOfOutEdges;
	for(UINT64 i = 1; i < graph->size(); i++)	// For each node in the graph
	{

		NumOfInEdges = 0; NumOfOutEdges = 0;
		listOfInEdges.clear(); listOfOutEdges.clear();
		/* Look for all the edges connected to this node */
		for(UINT64 j = 0; j< graph->at(i)->size(); j++)
		{
			Edge* e = graph->at(i)->at(j);
			/* If this node has a loop, do not consider it for tree reduction */
			if(e->getSourceRead()->getReadNumber() == e->getDestinationRead()->getReadNumber()) 
				break;
			if(e->getOrientation() == 0 || e->getOrientation() == 1 )	// It is an in-edge
			{
				NumOfInEdges++;
//				inFlow += e->flow;	// Count the in flow
				listOfInEdges.push_back(e);
			}
			else	// It is an out-edge
			{
				NumOfOutEdges++;
//				outFlow += e->flow;	// Count the out flow
				listOfOutEdges.push_back(e);
			}

		}
		/* If the flow is balanced, and there is only 1 inEdge or only 1 outEdge */
		//if(inFlow == outFlow && ( (NumOfInEdges == 1 && NumOfOutEdges > 1) || (NumOfInEdges > 1 && NumOfOutEdges == 1) ) )	// Either an in tree or an out tree
		if( (NumOfInEdges == 1 && NumOfOutEdges > 1) || (NumOfInEdges > 1 && NumOfOutEdges == 1) )	// Either an in tree or an out tree
		{
			nodeMerged++;
			for(UINT64 k = 0; k < listOfInEdges.size(); k++)
			{
				for(UINT64 l = 0; l < listOfOutEdges.size(); l++)
				{
					mergeEdges(listOfInEdges.at(k)->getReverseEdge(), listOfOutEdges.at(l));
				}
			}
			for(UINT64 k = 0; k < listOfInEdges.size(); k++)
			{
				removeEdge(listOfInEdges.at(k));
			}
			for(UINT64 l = 0; l < listOfOutEdges.size(); l++)
			{
				removeEdge(listOfOutEdges.at(l));
			}
		}
	}
	FILE_LOG(logINFO) << setw(10) << nodeMerged << " trees removed." << endl;
	CLOCKSTOP;
	return nodeMerged;
}


//=============================================================================
// This function remove loops
// a>--->b>--->b>--->c
// a<---<b<--->b>--->c
//=============================================================================
UINT64 OverlapGraph::reduceLoops(void)
{
	if(this->flowComputed == false)
	{
		return 0;
	}
	CLOCKSTART;
	UINT64 counter = 0, remove_counter = 0;
	Edge *ab,*bb,*bc;
	for(UINT64 i = 1; i < graph->size(); i++)
	{
		if(graph->at(i)->size() == 4) // only four edges. The loop is counted twice.
		{
			UINT64 loopCount = 0, incomingEdgeCount = 0, outgoingEdgeCount = 0;
			for(UINT64 j = 0; j< graph->at(i)->size(); j++)
			{
				if(graph->at(i)->at(j)->getDestinationRead()->getReadNumber() == i) // This is a loop
				{
					loopCount++;
					bb = graph->at(i)->at(j);
				}
				else if(graph->at(i)->at(j)->getOrientation() == 0 || graph->at(i)->at(j)->getOrientation() == 1) // incoming edge
				{
					incomingEdgeCount++;
					ab = graph->at(i)->at(j)->getReverseEdge();
				}
				else if(graph->at(i)->at(j)->getOrientation() == 2 || graph->at(i)->at(j)->getOrientation() == 3) // outgoing edge
				{
					outgoingEdgeCount++;
					bc = graph->at(i)->at(j);
				}
			}
			// Be aware that the loops without flow are not removed in function removeAllEdgesWithoutFlow.
			// Therefore if merge an edge with flow and a loop with flow 0, the resulted edge will have flow 0,
			// which is wrong. Here we will fix it, reassign the correct number of flow to the loop.
			// If later reduce tree with flow 0 and two other edges, then one edge with flow 0 would have been deleted before 
			// it's contracted with the other branch, wrong!
			// *** Now do not consider flow any more since it's not reliable with the removal of edges with flow
			// *** Whenever an edge with flow is removed, it creates an imbalance of flow at its incident nodes.
			
			if(loopCount==2 && incomingEdgeCount == 1 && outgoingEdgeCount == 1)  // two in the loop and one incoming and one outgoing
			{
				if(bb->getOrientation() == 0)
				{
					counter++;
					mergeEdges(ab,bb->getReverseEdge());
					removeEdge(ab);
					removeEdge(bb);
				}
				else if(bb->getOrientation() == 3)
				{
					counter++;
					mergeEdges(ab,bb);
					removeEdge(ab);
					removeEdge(bb);
				}
				else{
					FILE_LOG(logDEBUG) << "Loop has wrong orientation, cannot be used to reduce the graph" << endl;
					remove_counter++;
					removeEdge(bb);
				}
			}
			/* two in the loop and two incoming
			 * reduce in the case: *--->b>---<b<---* */
			else if (loopCount==2 && incomingEdgeCount == 2 && outgoingEdgeCount == 0 && bb->getOrientation() == 2){ // 
				counter++;
				mergeEdges(ab, bb);
				removeEdge(ab);
				removeEdge(bb);
			}
			/* two in the loop and two incoming
			 * reduce in the case: *---<b<--->b>---* */
			else if (loopCount==2 && incomingEdgeCount == 0 && outgoingEdgeCount == 2 && bb->getOrientation() == 1){ // 
				counter++; mergeEdges(bb, bc);
				removeEdge(bc);
				removeEdge(bb);
			}
			/* Cannot reduce graph */
			else if (loopCount == 2 && bb->getDestinationRead()->getReadNumber()!=0){
				remove_counter++;
				removeEdge(bb);
			}
		}
	}
	if(counter > 0 || remove_counter > 0){
		FILE_LOG(logINFO) <<" Loops reduced: " << counter << endl; // Number of loop we were able to reduce
		FILE_LOG(logINFO) <<" Loops removed: " << remove_counter << endl; // Number of loop we were able to reduce
	}
	CLOCKSTOP;
	return counter;
}


//=============================================================================
// Calculate min cost flow
//
// An sample input to the CS2 algorithm
//
// p min       3840      13449	// p min numberOfNodes numberOfEdges
// n          1         0	// initial flow of 0 in node 1, node 1 is the supersource
// n       3840         0	// initial flow of 0 in node 3840, which is the supersink (equal to the number of nodes)
// a       3840          1          1    1000000    1000000	// edge from supersink to supersource, LowBound(1), UpperBound(1000000), Cost per unit of flow(1000000)
// a          1          2          0    1000000          0	// edge from supersource to node 2, with the defined cost function
// this continues to
// connect each node to supersource and supersink
// connect every edge in the original graph
//=============================================================================

void OverlapGraph::calculateFlowStream(void) 
{
	CLOCKSTART;
	// Add super source and super sink nodes, add edge from super sink to super source with very big cost
	// Add edge from super source to every node in the graph, also from every node in the graph to the super sink
	// Every edge will be assigned a lower bound and an upper bound of the flow (capacity), and the cost associated with the edge
	// NEW CHANGES:
	// Now change the initial flow so that super source only connects to the source nodes (no in-edges only out-edges), and
	// only sink nodes connect to the super sink. This way the simple edges that are not really needed but that will make the paths longer will be kept.
	//
	UINT64 V = numberOfNodes*2 + 2, E = numberOfEdges * 3 + numberOfNodes * 4 + 1 , SUPERSOURCE = 1, SUPERSINK = V;
	INT64 FLOWLB[3], FLOWUB[3], COST[3];            // Flow bounds and cost of the edges, cost function originally is a piecewise function with 3 segments
	stringstream ss;
	ss << "p min " << setw(10) << V << " " << setw(10) << E << endl;    // Problem description: Number of nodes and edges in the graph.
	ss << "n " << setw(10) << SUPERSOURCE << setw(10) << " 0" << endl;  // Flow in the super source
	ss << "n " << setw(10) << SUPERSINK << setw(10) << " 0" << endl;    // Flow in the super sink.

	// Flow lower bound and upper bound, and the cost for the first segment in the piecewise cost function
	FLOWLB[0] = 1; FLOWUB[0] = 1000000; COST[0] = 1000000;
	ss << "a " << setw(10) << SUPERSINK << " " << setw(10) << SUPERSOURCE << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl; // Add an edge from super sink to super source with very high cost (almost infinity), also at most can be used once


	// If the ID of a node in the original graph is 100 and directed graph is 5
	// Then listOfNodes->at(100) is equal to 5
	// and ListOfNodesReverse->at(5) is equal to 100.
	vector<UINT64> *listOfNodes = new vector<UINT64>;
	vector<UINT64> *listOfNodesReverse = new vector<UINT64>;

	for(UINT64 i = 0; i <= graph->size(); i++)      // For n nodes in the graph, CS2 requires that the nodes are numbered from 1 to n. In the overlap graph, the nodes does not have sequencinal ID. We need to convert them to 1 - n
	{
		listOfNodes->push_back(0);
		listOfNodesReverse->push_back(0);
	}

	// This loop set lower bound and upper bound from super source to each node, and from each node to super sink. All costs are 0.
	// This loop set lower bound and upper bound from super source to super sink. All costs are 0.
	UINT64 currentIndex = 1;
	for(UINT64 i = 1; i < graph->size(); i++)
	{
		if(!graph->at(i)->empty()) // edges to and from the super source and super sink
		{
			listOfNodes->at(i) = currentIndex;                                      // Mapping between original node ID and cs2 node ID
			listOfNodesReverse->at(currentIndex) = i;                       // Mapping between original node ID and cs2 node ID
			FLOWLB[0] = 0; FLOWUB[0] = 1000000; COST[0] = 0;
			ss << "a " << setw(10) << SUPERSOURCE << " " << setw(10) << 2 * currentIndex << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
			ss << "a " << setw(10) << SUPERSOURCE << " " << setw(10) << 2 * currentIndex + 1 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
			ss << "a " << setw(10) << 2 * currentIndex << " " << setw(10) << SUPERSINK << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
			ss << "a " << setw(10) << 2 * currentIndex + 1 << " " << setw(10) << SUPERSINK << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
			currentIndex++;
		}
	}

//#ifdef DEBUG
//	ofstream mapout("originalID_flowID.map");
//	for(size_t i = 0; i < listOfNodes->size(); i++){
//		UINT64 ind = listOfNodes->at(i);
//		mapout << i << " " << 2*ind << " F" << endl; /* forward */
//		mapout << i << " " << 2*ind  + 1 << " R" <<endl; /* reverse */
//	}
//	mapout.close();
//#endif
	// This loop converts the original bi-directed edges to directed edges (1 becomes 6).
	for(UINT64 i = 1; i < graph->size(); i++) {
		if(!graph->at(i)->empty()) // edges to and from the super source and super sink
		{
			for(UINT64 j = 0; j < graph->at(i)->size(); j++)
			{
				Edge *edge = graph->at(i)->at(j);
				UINT64 u = listOfNodes->at(edge->getSourceRead()->getReadNumber());
				UINT64 v = listOfNodes->at(edge->getDestinationRead()->getReadNumber());

				// set the bound and cost here
				// if edge has more than 20 reads:
				//   FLOWLB[0] = 1; FLOWUB[0] = 1; COST[0] = 1;
				//   FLOWLB[1] = 0; FLOWUB[1] = 1; COST[1] = 50000;
				//   FLOWLB[2] = 0; FLOWUB[2] = 8; COST[2] = 100000;
				// else:
				//   FLOWLB[0] = 0; FLOWUB[0] = 1; COST[0] = 1;
				//   FLOWLB[1] = 0; FLOWUB[1] = 1; COST[1] = 50000;
				//   FLOWLB[2] = 0; FLOWUB[2] = 8; COST[2] = 100000;

				if(u < v || (u == v && edge < edge->getReverseEdge()))
				{
					calculateBoundAndCost(edge, FLOWLB, FLOWUB, COST);
					// Here for each edge we add three edges with different values of cost and bounds.
					// Total 6 edges considering the reverse edge too.
					// For details on how to convert the edges off different types please see my thesis.
					UINT64 u1 = 2 * u, u2 = 2 * u + 1, v1 =  2 * v, v2 = 2 * v + 1;
					if(edge->getOrientation() == 0)
					{
						ss << "a " << setw(10) << v1 << " " << setw(10) << u1 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
						ss << "a " << setw(10) << u2 << " " << setw(10) << v2 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;

						ss << "a " << setw(10) << v1 << " " << setw(10) << u1 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;
						ss << "a " << setw(10) << u2 << " " << setw(10) << v2 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;

						ss << "a " << setw(10) << v1 << " " << setw(10) << u1 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;
						ss << "a " << setw(10) << u2 << " " << setw(10) << v2 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;
					}
					else if(edge->getOrientation() == 1)
					{
						ss << "a " << setw(10) << v2 << " " << setw(10) << u1 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
						ss << "a " << setw(10) << u2 << " " << setw(10) << v1 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;

						ss << "a " << setw(10) << v2 << " " << setw(10) << u1 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;
						ss << "a " << setw(10) << u2 << " " << setw(10) << v1 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;

						ss << "a " << setw(10) << v2 << " " << setw(10) << u1 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;
						ss << "a " << setw(10) << u2 << " " << setw(10) << v1 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;

					}
					else if(edge->getOrientation() == 2)
					{
						ss << "a " << setw(10) << u1 << " " << setw(10) << v2 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
						ss << "a " << setw(10) << v1 << " " << setw(10) << u2 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;

						ss << "a " << setw(10) << u1 << " " << setw(10) << v2 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;
						ss << "a " << setw(10) << v1 << " " << setw(10) << u2 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;

						ss << "a " << setw(10) << u1 << " " << setw(10) << v2 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;
						ss << "a " << setw(10) << v1 << " " << setw(10) << u2 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;

					}
					else if(edge->getOrientation() == 3)
					{
						ss << "a " << setw(10) << u1 << " " << setw(10) << v1 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;
						ss << "a " << setw(10) << v2 << " " << setw(10) << u2 << " " << setw(10) << FLOWLB[0] << " " << setw(10) << FLOWUB[0] << " " << setw(10) << COST[0] << endl;

						ss << "a " << setw(10) << u1 << " " << setw(10) << v1 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;
						ss << "a " << setw(10) << v2 << " " << setw(10) << u2 << " " << setw(10) << FLOWLB[1] << " " << setw(10) << FLOWUB[1] << " " << setw(10) << COST[1] << endl;

						ss << "a " << setw(10) << u1 << " " << setw(10) << v1 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;
						ss << "a " << setw(10) << v2 << " " << setw(10) << u2 << " " << setw(10) << FLOWLB[2] << " " << setw(10) << FLOWUB[2] << " " << setw(10) << COST[2] << endl;

					}
				}
			}
		}
	}

/* #ifdef DEBUG
 * 	ofstream flowin("init.flow");
 * 	flowin << ss.str();
 * 	flowin.close();
 * #endif
 */
	stringstream oss;                       // stringstream to catch the output
	// FILE_LOG(logINFO) << "Calling CS2 for flow analysis";
	main_cs2(&ss, oss);         // Call CS2
	// FILE_LOG(logINFO) << "Flow analysis finished";

/* #ifdef DEBUG
 * 	ofstream flowout("calc.flow");
 * 	flowout << oss.str();
 * 	flowout.close();
 * #endif
 */

	string s, d, f;
	UINT64 lineNum = 0;
	//ofstream yesflow("edges_with_flow.flow");
	while(!oss.eof()) {
		lineNum ++;
		UINT64 source, destination, flow;
		oss >> source >> destination >> flow;	// get the flow from CS2

		UINT64 mySource = listOfNodesReverse->at(source/2);	// Map the source to the original graph
		UINT64 myDestination = listOfNodesReverse->at(destination/2);	// Map the destination in the original graph
		//string orient_source = (source % 2 == 0) ? "F" : "R";
		//string orient_dest = (destination % 2 == 0) ? "F" : "R";

		if(source != SUPERSINK && source != SUPERSOURCE && destination != SUPERSOURCE && destination != SUPERSINK && flow!=0)
		{
			Edge *edge = (findEdges(mySource, myDestination)).at(0);	// Find the edge in the original graph.
			edge->flow += flow;	// Add the flow in the original graph.
			edge->getReverseEdge()->flow += flow;	// Also add the same flow to the twin edge to make sure that the flow is the same for the twin edges (flow is doubled if both directions have same flow)
			//yesflow << mySource << " " << myDestination << " " << flow << " " << orient_source << " " << orient_dest  << " " << edge->getListOfReads()->size() << endl;		
			// TODO: Take care of the reassignment of flow for bubble edges
		}
		//else
			//yesflow << mySource << " " << myDestination << " " << flow << " " << orient_source << " " << orient_dest << endl;		

	}
	//yesflow.close();
	delete listOfNodes;
	delete listOfNodesReverse;
	this->flowComputed = true;

/* #ifdef DEBUG
 * 	vector<Edge *> contigEdges;
 * 	getEdges(contigEdges);
 * 	printGraph("debug_graph_with_flow.gdl", contigEdges);
 * #endif
 */

	CLOCKSTOP;
}



//=============================================================================
// This function calculates the cost and bounds for an edge in the overlap graph.
// This function is very sensitive to the assembled contigs and to the cost function parameters
//=============================================================================
void OverlapGraph::calculateBoundAndCost(const Edge *edge, INT64* FLOWLB, INT64* FLOWUB, INT64* COST)
{
	for(UINT64 i = 0; i < 3; i++)		// For the simple edges we put very high cost
	{
		FLOWLB[i] = 0; FLOWUB[i] = 10; COST[i] = 500000;
	}

	if(!edge->getListOfReads()->empty()) // Composite Edge
	{
		// Case1: Composite Edge of at least minFlowReadCountThreshold (default: 20) reads. Must have at least one unit of flow.
		// Case2: Composite Edge length is longer than minFlowEdgeLengthThreshold (default: 1000)
		if(edge->getListOfReads()->size() >= minReadsCountInEdgeToBe1MinFlow || edge->getEdgeLength() > minEdgeLengthToBe1MinFlow)
		{
			s_nGoodEdges++;
			s_nReads_in_goodEdges += edge->getListOfReads()->size();
			// the first 1 flow must be used and has a cost of 1
			// each additional flow up to 8 flows has a cost of 100000

			// this edge carry the first 1 flow
			FLOWLB[0] = 1; FLOWUB[0] = 1; COST[0] = 1;
			// this edge carries the second 1 flow with high cost
			FLOWLB[1] = 0; FLOWUB[1] = 1; COST[1] = 50000;
			// this edge provides additional flow after the second flow
			FLOWLB[2] = 0; FLOWUB[2] = 8; COST[2] = 100000;
		}
		else // Short composite edge containing less than 20 reads. May have zero flow.
		{
			// the first 1 flow may not be required, but has a low cost of 1
			// each additional flow up to 8 flows has a cost of 100000

			// this edge carries the first 1 flow
			FLOWLB[0] = 0; FLOWUB[0] = 1; COST[0] = 1;
			// this edge carries the second unit of flow with high cost
			FLOWLB[1] = 0; FLOWUB[1] = 1; COST[1] = 50000;
			// this edge provides additional flow after the two units of flow.
			FLOWLB[2] = 0; FLOWUB[2] = 8; COST[2] = 100000;
		}
	}
}


//=============================================================================
// Return edge between source and destination
//=============================================================================
Edge * OverlapGraph::findEdge(const UINT64 & source, const UINT64 & destination)
{
	for(UINT64 i = 0; i < graph->at(source)->size(); i++) // For the list of edges of the source node.
	{
		if(graph->at(source)->at(i)->getDestinationRead()->getReadNumber() == destination)	// check if there is an edge to destination
			return graph->at(source)->at(i);	// return the edge.
	}
	FILE_LOG(logERROR) << "Cannot find edge from " << source << " to " << destination << endl;
	return (graph->at(0)->at(0));
}


//=============================================================================
// Return edges between source and destination
//=============================================================================
vector<Edge *> OverlapGraph::findEdges(const UINT64 & source, const UINT64 & destination)
{
	vector<Edge *> edges;
	for(UINT64 i = 0; i < graph->at(source)->size(); i++) // For the list of edges of the source node.
	{
		if(graph->at(source)->at(i)->getDestinationRead()->getReadNumber() == destination)	// check if there is an edge to destination
		{
			edges.push_back(graph->at(source)->at(i));	// return the edge.
		}
		// Since the edges are sorted by the destination read number in increasing order,
		// once passed the wanted read number, quit
	}
	if(edges.size() == 0){
		FILE_LOG(logERROR) << "Cannot find edge from " << source << " to " << destination << endl;
	}
	// Sort the edges by number of reads contained in decreasing order
	sort(edges.begin(),edges.end(),compareEdgesByReads);
	return edges;
}


//=============================================================================
// Remove all edges in the overlap graph that do not have any flow.
//=============================================================================
UINT64 OverlapGraph::removeAllEdgesWithoutFlow()
{
	CLOCKSTART;
	vector <Edge *> listOfEdges;
//	ofstream noFlow("noFlow.edges");
	for(UINT64 i = 1; i < graph->size(); i++) // For each read.
	{
		if(!graph->at(i)->empty())	// If the read has some edges.
		{
			for(UINT64 j=0; j < graph->at(i)->size(); j++) // For each edge
			{
				Edge * edge = graph->at(i)->at(j);

				UINT64 source = edge->getSourceRead()->getReadNumber();
				UINT64 destination = edge->getDestinationRead()->getReadNumber();

				//Also remove loops without flow. This means, by default, 
				//the edges formed by loops that do not contain many reads will not be used.
				if(edge->flow == 0 && (source < destination || (source==destination && edge < edge->getReverseEdge())))
				{
					listOfEdges.push_back(edge); // Put in the list of edges to be removed.
//					if (loglevel > 2)
//						noFlow << *edge << endl;
				}
			}
		}
	}
//	noFlow.close();
	for(UINT64 i = 0 ; i < listOfEdges.size(); i++)
	{
		removeEdge(listOfEdges.at(i));	// remove the edges from the list.
	}
	FILE_LOG(logINFO) <<"No flow edges removed: " << listOfEdges.size() << endl;
	CLOCKSTOP;
	return listOfEdges.size();
}


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  getEdges
 *  Description:  save all the edges in the graph in a vector of pointers to these edges
 * =====================================================================================
 */
void OverlapGraph::getEdges(vector<Edge *> & contigEdges)
{
	CLOCKSTART;
	FILE_LOG(logDEBUG) << "deleted edges saved: " << deletedEdges->size() << endl;
	contigEdges.clear();
	UINT64 contigEdgeID = 1;
	for(UINT64 i = 1; i<= dataSet->getNumberOfUniqueReads(); i++)
	{
		if(!graph->at(i)->empty()) // if this read has some edge(s) going out of it (since now the graph is directed)
		{
			for(UINT64 j = 0; j < graph->at(i)->size(); j++)
			{
				Edge * e = graph->at(i)->at(j);
				UINT64 source = e->getSourceRead()->getReadNumber(), destination = e->getDestinationRead()->getReadNumber();
				if(source < destination || (source == destination && e < e->getReverseEdge()) )  /* Only consider the edges between non-contained reads */
				{
					contigEdges.push_back(e); // List of contigs.
					e->contigEdgeID = contigEdgeID;
					contigEdgeID++;
				}
			}
		}
		if (deletedEdges->size() > 0){
			for (UINT64 i = 0; i < deletedEdges->size(); ++i){
				Edge * e = deletedEdges->at(i);
				UINT64 source = e->getSourceRead()->getReadNumber(), destination = e->getDestinationRead()->getReadNumber();
				if(source < destination || (source == destination && e < e->getReverseEdge()) )  /* Only consider the edges between non-contained reads */
				{
					contigEdges.push_back(e); // List of contigs.
					e->contigEdgeID = contigEdgeID;
					contigEdgeID++;
				}
			}
		}
	}
	CLOCKSTOP;
}

/*=============================================================================
  This function prints the overlap graph in overlap_graph->gdl file. The graph can be viewed by
  aisee (free software available at http://www.aisee.com/)
  It also stores the contigs in a file.

graph: {
layoutalgorithm :forcedir
fdmax:704
tempmax:254
tempmin:0
temptreshold:3
tempscheme:3
tempfactor:1.08
randomfactor:100
gravity:0.0
repulsion:161
attraction:43
ignore_singles:yes
node.fontname:"helvB10"
edge.fontname:"helvB10"
node.shape:box
node.width:80
node.height:20
node.borderwidth:1
node.bordercolor:31
node: { title:"43" label: "43" }	// node, Title and label are both node ID 43 (and read number)
node: { title:"65" label: "65" }
............................................
............................................
// edges from source node 43 to destination node 32217, thickness of 3 means composite edge, thickness of 1 for simple edge
// edge type of backarrowstyle:solid arrowstyle:solid color: green is >----------------<
// edge type of arrowstyle:solid color: red is <----------------<
// edge type of arrowstyle: none color: blue  is <------------------->
// (1,0x,206,30) means (Flow, coverageDepth, OverlapOffset, numberOfReads)

edge: { source:"43" target:"32217" thickness: 3 backarrowstyle:solid arrowstyle:solid color: green label: "(1,0x,206,30)" }
edge: { source:"65" target:"38076" thickness: 3 arrowstyle:solid color: red label: "(0,0x,75,11)" }
edge: { source:"280" target:"47580" thickness: 3 arrowstyle: none color: blue label: "(0,0x,123,11)" }
}
=============================================================================*/
/**********************************************************************************************************************
 * This function prints the overlap graph in overlap_graph->gdl file. 
 * The graph can be viewed by aisee (free software available at http://www.aisee.com/) 
 * It also stores the contigs in a file.
 **********************************************************************************************************************/
void OverlapGraph::printGraph(const string & graphFileName, const vector<Edge *> & contigEdges)
{
	CLOCKSTART;
	UINT64 thickness;
	string edgeColor;
	ofstream graphFilePointer; 

	/************************* Store the graph in a file. ************************/
	graphFilePointer.open(graphFileName.c_str());
	if(!graphFilePointer.is_open())
		MYEXIT("Unable to open file: "+graphFileName);

	// Graph specification before the nodes and edges
	graphFilePointer << "graph: {" << endl <<  "layoutalgorithm :forcedir" << endl <<  "fdmax:704" << endl <<  "tempmax:254" << endl <<  "tempmin:0" << endl <<  "temptreshold:3" << endl <<  "tempscheme:3" << endl <<  "tempfactor:1.08" << endl <<  "randomfactor:100" << endl <<  "gravity:0.0" << endl <<  "repulsion:161" << endl <<  "attraction:43" << endl <<  "ignore_singles:yes" << endl <<  "node.fontname:\"helvB10\"" << endl << "edge.fontname:\"helvB10\"" << endl <<  "node.shape:box" << endl <<  "node.width:80" << endl <<  "node.height:20" << endl <<  "node.borderwidth:1" << endl <<  "node.bordercolor:31" << endl;

	// All the nodes, title and label
	for(UINT64 i = 1; i<= dataSet->getNumberOfUniqueReads(); i++)
	{
		if(!graph->at(i)->empty())
			graphFilePointer << "node: { title:\""<< i <<"\" label: \"" << i << "\" }" << endl;	// Print nodes even if there are no edge connected to it
	}

	// All the edges
	for (UINT64 i = 0; i < contigEdges.size(); i++)
	{
		Edge * e = contigEdges.at(i);
		thickness = e->getListOfReads()->empty() ? 1: 3;
		UINT64 source = e->getSourceRead()->getReadNumber(), destination = e->getDestinationRead()->getReadNumber();
		// Edge label: (first overlap length, edge length, number of reads, overlap offset, last overlap length)
		if(source < destination || (source == destination && e < e->getReverseEdge()) )
		{
			if(e->getOrientation() == 0)
				graphFilePointer << "edge: { source:\"" << source << "\" target:\"" << destination
					<< "\" thickness: " << thickness << " arrowstyle: none backarrowstyle: solid color: red label: \"(" 
					<< e->getOverlapLen() << "," << e->getEdgeLength() << "," << e->getListOfReads()->size() << "," << e->getOverlapOffset()
					<< "," << e->getReverseEdge()->getOverlapLen()
					<< ")\" }" << endl;
			else if(e->getOrientation() == 1)
				graphFilePointer << "edge: { source:\"" << source << "\" target:\"" << destination << "\" thickness: "
					<< thickness << " backarrowstyle:solid arrowstyle:solid color: green label: \"(" 
					<< e->getOverlapLen() << "," << e->getEdgeLength() << "," << e->getListOfReads()->size() << "," << e->getOverlapOffset()
					<< "," << e->getReverseEdge()->getOverlapLen()
					<< ")\" }" << endl;
			else if(e->getOrientation() == 2)
				graphFilePointer << "edge: { source:\"" << source << "\" target:\"" << destination << "\" thickness: "
					<< thickness << " arrowstyle: none color: blue label: \"(" 
					<< e->getOverlapLen() << "," << e->getEdgeLength() << "," << e->getListOfReads()->size() << "," << e->getOverlapOffset()
					<< "," << e->getReverseEdge()->getOverlapLen()
					<< ")\" }" << endl;
			else if(e->getOrientation() == 3)
				graphFilePointer << "edge: { source:\"" << source << "\" target:\"" << destination << "\" thickness: "
					<< thickness << " arrowstyle:solid color: red label: \"(" 
					<< e->getOverlapLen() << "," << e->getEdgeLength() << "," << e->getListOfReads()->size() << "," << e->getOverlapOffset()
					<< "," << e->getReverseEdge()->getOverlapLen()
					<< ")\" }" << endl;
		}
	}
	graphFilePointer << "}";
	graphFilePointer.close();
	CLOCKSTOP;
	/************************* Store the graph in a file done. ************************/
}


//=============================================================================
// Functions for printContigsStream
//=============================================================================
bool longerVectors(const vector<char>& a, const vector<char>& b)
{
	return a.size() > b.size();
}

struct by_second
{
    template <typename Pair>
    bool operator()(const Pair& a, const Pair& b)
    {
        return a.second < b.second;
    }
};

template <typename Fwd>
typename std::map<typename std::iterator_traits<Fwd>::value_type, int>::value_type
most_frequent_element(Fwd begin, Fwd end)
{
    std::map<typename std::iterator_traits<Fwd>::value_type, int> count;

    for (Fwd it = begin; it != end; ++it)
        ++count[*it];

    return *std::max_element(count.begin(), count.end(), by_second());
}


//=============================================================================
// Print contigs from read streaming to reduce memory usage
//=============================================================================
void OverlapGraph::printContigsStream(const vector<string> &readFilenameList, const string & contigFastaFilename, vector<Edge *> & contigEdges)
{
	CLOCKSTART;

	FILE_LOG(logINFO) << "Print contigs to file" << endl;
	if (contigEdges.size() > 0) // Sort the contigs by their length if there are edges in the graph.
	{
		// for contig fasta output file
		ofstream contigFastaFilePointer(contigFastaFilename.c_str());
		if(!contigFastaFilePointer.is_open())
			MYEXIT("Unable to open file: " + contigFastaFilename);


		// Reads
		UINT64 readID = 0;
		UINT64 numOfUniqueRead = 0;	// Initialize
		UINT64 numOfUniqueReadEachFile = 0;	// Initialize

		// vector of contig strings
		vector<vector<char> > contigStrings (contigEdges.size());
		for ( UINT32 i = 0 ; i < contigEdges.size() ; i++ )
		{
			Edge * e = contigEdges.at(i);
			contigStrings[i].resize(e->getEdgeLength());
		}

		// initialize mismatchMap
		vector<unordered_map<UINT32, vector<char> > > mismatchMap (contigEdges.size());
		for ( UINT32 i = 0 ; i < contigEdges.size() ; i++ )
		{
			Edge * e = contigEdges.at(i);
			for ( UINT32 j = 0 ; j < e->getMismatches()->size() ; j++ )
			{
				// Add valid key (mismatch position = e->getMismatches()->at(j).second) without explicit value
				mismatchMap.at(i)[e->getMismatches()->at(j).second];
			}
		}

		// loop readFilenameList
		for (vector<string>::const_iterator it = readFilenameList.begin(); it != readFilenameList.end(); ++it)
		{
			readID = numOfUniqueRead+1;
			numOfUniqueReadEachFile = streamReadFileSequences(*it, readID, contigStrings, mismatchMap);
			numOfUniqueRead += numOfUniqueReadEachFile;
		}

		// loop mismatches and update the sequence
		for ( UINT32 i = 0 ; i < mismatchMap.size() ; i++ )
		{
			for(unordered_map<UINT32, vector<char> >::iterator it=mismatchMap.at(i).begin(); it!=mismatchMap.at(i).end(); it++)
			{
				UINT32 position = it->first;
				vector<char> v = it->second;
				// get most frequent element and update contigString with it
			    std::pair<char, int> x = most_frequent_element(v.begin(), v.end());
			    contigStrings.at(i).at(position) = x.first;
			}
		}

		// sort contigStrings
		sort(contigStrings.begin(), contigStrings.end(), longerVectors);	// Sort the contigs by their total string length, in decreasing order

		UINT64 printed_contigs(0);
		for ( UINT64 i = 0; i < contigStrings.size(); i++ )
		{
			// get contig string
			string contigString(contigStrings.at(i).begin(), contigStrings.at(i).end());
			// cout << "contigString= " << contigString << endl;
			if(contigString.length() >= minContigLengthTobeReported){
				++printed_contigs;
				contigFastaFilePointer << ">contig_" << setfill('0') << setw(10) << i+1	
					<< " Edge ("  << contigEdges.at(i)->getSourceRead()->getReadNumber() << ", " << contigEdges.at(i)->getDestinationRead()->getReadNumber() << ") String Length: " << contigString.length() << endl;
				//contigEdgesFilePointer << ">contig_" << setfill('0') << setw(10) << i+1  << "\t" << *(contigEdges.at(i)) << endl;

				UINT32 start=0;
				do
				{
					contigFastaFilePointer << contigString.substr(start, 100) << endl;  // save 100 BP in each line.
					start+=100;
				} while (start < contigString.length());
			}
		}
		FILE_LOG(logINFO) << "Total number of contigs printed: " << printed_contigs << endl;

		// open file close
		contigFastaFilePointer.close();
		//contigEdgesFilePointer.close();
	}

	CLOCKSTOP;
}


//=============================================================================
// Load the reads in stream again on each file to print the contigs
//=============================================================================
UINT64 OverlapGraph::streamReadFileSequences(const string &readFilename, UINT64 &readID, vector<vector<char> > & contigStrings, vector<unordered_map<UINT32, vector<char> > > & mismatchMap)
{
	CLOCKSTART;

	// To count of reads
	UINT64 readCount = 0;

	// Open file
	ifstream filePointer;
	filePointer.open(readFilename.c_str());
	if(!filePointer.is_open())
		MYEXIT("Unable to open file: "+readFilename);

	// Variables
	vector<string> line;
	string line0,line1, text;
	enum FileType {FASTA, FASTQ, UNDEFINED};
	FileType fileType = UNDEFINED;

	while(!filePointer.eof())
	{
		// Check FASTA and FASTQ
		if(fileType == UNDEFINED)
		{
			getline (filePointer,text);
			if(text[0] == '>')
				fileType = FASTA;
			else if(text[0] == '@')
				fileType = FASTQ;
			else
				FILE_LOG(logERROR)<< "Unknown input file format."<<endl;
			filePointer.seekg(0, ios::beg);
		}

		// Clear line
		line.clear();

		// FASTA file read
		if(fileType == FASTA)
		{
			getline (filePointer,text);	// get ID line
			line.push_back(text);
			getline (filePointer,text,'>');	// get string line
			line.push_back(text);

			line.at(1).erase(std::remove(line.at(1).begin(), line.at(1).end(), '\n'), line.at(1).end());
			line0 = line.at(0);	// ID
			line1 = line.at(1);	// String

		}
		// FASTQ file read
		else if(fileType == FASTQ)
		{
			for(UINT64 i = 0; i < 4; i++)   // Total of 4 lines represent one sequence in a FASTQ file.
			{
				getline (filePointer,text);
				line.push_back(text);
			}
			line0 = line.at(0);	// ID
			line1 = line.at(1);	// String
		}

		string readString, forwardString, reverseString;
		for (std::string::iterator p = line1.begin(); line1.end() != p; ++p)
			*p = toupper(*p);
		forwardString = line1;
		reverseString = reverseComplement(line1);

		// target read
		Read *targetRead = dataSet->getReadFromID(readID);
		string targetReadSequence;
		UINT64 startIndex, positionIndex;
		UINT64 contigIndex;

		// source and destination reads handling
		if(!graph->at(readID)->empty()) // if this read has some edge(s) going out of it (since now the graph is directed)
		{
			for(UINT64 j = 0; j < graph->at(readID)->size(); j++)
			{
				Edge * e = graph->at(readID)->at(j);
				Edge * eRev = e->getReverseEdge();

				UINT64 source = e->getSourceRead()->getReadNumber(), destination = e->getDestinationRead()->getReadNumber();
				if(source < destination || (source == destination && e < e->getReverseEdge()) )  // Only consider the edges between non-contained reads
				{

					// sequence of the source read
					targetReadSequence = (e->getOrientation() == 2 || e->getOrientation() == 3) ?  forwardString : reverseString;
					startIndex = 0;
					contigIndex = e->contigEdgeID - 1;

				    for (UINT64 m = 0; m < targetReadSequence.length(); m++)
				    {
				    	positionIndex = startIndex + m;
				    	// mismatch found
						unordered_map<UINT32, vector<char> >::const_iterator got_mismatch = mismatchMap.at(contigIndex).find (positionIndex);
						if ( got_mismatch != mismatchMap.at(contigIndex).end() ) {
							mismatchMap.at(contigIndex)[positionIndex].push_back(targetReadSequence.at(m));
						}

				    	// insert/update character to the contigStrings
						if (positionIndex < contigStrings.at(contigIndex).size() )
				    		contigStrings.at(contigIndex).at(positionIndex) = targetReadSequence.at(m);
						else
							MYEXIT("** Error: contigString index exceed error!");
				    }
				}
				else
				{
					// sequence of the destination read
					targetReadSequence = (eRev->getOrientation() == 1 || eRev->getOrientation() == 3) ?  forwardString : reverseString;
					startIndex = eRev->getOverlapOffset();
					contigIndex = eRev->contigEdgeID - 1;

					for (UINT64 m = 0; m < targetReadSequence.length(); m++)
					{
						positionIndex = startIndex + m;
				    	// mismatch found
						unordered_map<UINT32, vector<char> >::const_iterator got_mismatch = mismatchMap.at(contigIndex).find (positionIndex);
						if ( got_mismatch != mismatchMap.at(contigIndex).end() ) {
							mismatchMap.at(contigIndex)[positionIndex].push_back(targetReadSequence.at(m));
						}

						if (positionIndex < contigStrings.at(contigIndex).size() )
					    	contigStrings.at(contigIndex).at(positionIndex) = targetReadSequence.at(m);
						else
							MYEXIT("** Error: contigString index exceed error!");
					}
				}
			}
		}
		// contained reads handling
		else
		{
			// getListOfEdgesForward
			for(UINT64 j = 0; j < targetRead->getListOfEdgesForward()->size(); j++)
			{
				Edge *e = targetRead->getListOfEdgesForward()->at(j);
				UINT64 source = e->getSourceRead()->getReadNumber(), destination = e->getDestinationRead()->getReadNumber();
				if(source < destination || (source == destination && e < e->getReverseEdge()) )  // Only consider the edges between non-contained reads
				{
					// target sequence should be forward
					targetReadSequence = forwardString;
					startIndex = targetRead->getLocationOnEdgeForward()->at(j);
					contigIndex = e->contigEdgeID - 1;

					for (UINT64 m = 0; m < targetReadSequence.length(); m++)
					{
						positionIndex = startIndex + m;
				    	// mismatch found
						unordered_map<UINT32, vector<char> >::const_iterator got_mismatch = mismatchMap.at(contigIndex).find (positionIndex);
						if ( got_mismatch != mismatchMap.at(contigIndex).end() ) {
							mismatchMap.at(contigIndex)[positionIndex].push_back(targetReadSequence.at(m));
						}

						if (positionIndex < contigStrings.at(contigIndex).size() )
				    		contigStrings.at(contigIndex).at(positionIndex) = targetReadSequence.at(m);
						else
							MYEXIT("** Error: contigString index exceed error!");
					}
				}
			}

			// getListOfEdgesReverse
			for(UINT64 j = 0; j < targetRead->getListOfEdgesReverse()->size(); j++)
			{
				Edge *e = targetRead->getListOfEdgesReverse()->at(j);
				UINT64 source = e->getSourceRead()->getReadNumber(), destination = e->getDestinationRead()->getReadNumber();
				if(source < destination || (source == destination && e < e->getReverseEdge()) )  // Only consider the edges between non-contained reads
				{
					// target sequence should be reverse
					targetReadSequence = reverseString;
					startIndex = e->getEdgeLength() - (targetRead->getReadLength() + targetRead->getLocationOnEdgeForward()->at(j));
					contigIndex = e->contigEdgeID - 1;
	
					for (UINT64 m = 0; m < targetReadSequence.length(); m++)
					{
						positionIndex = startIndex + m;
				    	// mismatch found
						unordered_map<UINT32, vector<char> >::const_iterator got_mismatch = mismatchMap.at(contigIndex).find (positionIndex);
						if ( got_mismatch != mismatchMap.at(contigIndex).end() ) {
							mismatchMap.at(contigIndex)[positionIndex].push_back(targetReadSequence.at(m));
						}

						if (positionIndex < contigStrings.at(contigIndex).size() )
				    		contigStrings.at(contigIndex).at(positionIndex) = targetReadSequence.at(m);
						else
							MYEXIT("** Error: contigString index exceed error!");
					}
				}
			}
		}

		readCount ++;
		readID ++;
	}
	filePointer.close();
	CLOCKSTOP;

	return readCount;
}

