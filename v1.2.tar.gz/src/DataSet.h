#ifndef DATASET_H
#define DATASET_H

//============================================================================
// Name        : DataSet.h
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : DataSet header file
//============================================================================

#include "Config.h"
#include "Read.h"

class DataSet
{
	private:
		vector<Read *> *reads;

	public:
		DataSet();
		~DataSet();

		UINT64 numberOfUniqueReads;

		void addRead(Read *r){reads->push_back(r);}

		UINT64 getNumberOfUniqueReads (void) const{ return numberOfUniqueReads;}

		Read * getReadFromID(UINT64 ID) const;
};

#endif /* DATASET_H */
