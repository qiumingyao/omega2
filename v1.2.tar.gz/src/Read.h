#ifndef READ_H
#define READ_H

//============================================================================
// Name        : Read.h
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : Read header file
//============================================================================

#include "Config.h"

class Edge;


class Read
{
	private:
		UINT64 readNumber;	// Unique Identification of the read.
		string read;	// String representation of the read.
		string readReverse;
		UINT32 readLength;	// Length of the read.
		vector<Edge *> *listOfEdgesForward;	// List of edges that contain the forward string of this read.
		vector<UINT32> *locationOnEdgeForward;	// List of locations on the edges that contain the forward string of the current read.
		vector<Edge *> *listOfEdgesReverse;	// List of edges that contain the reverse string of this read.
		vector<UINT32> *locationOnEdgeReverse;	// List of locations on the edges that contain the reverse string of the current read.

	public:
		Read(void);	// Default constructor.
		Read(const string & s);	// Another constructor.
		~Read(void);	// Destructor.

		void setReadNumber(const UINT64 & id);	// Set the read number.
		void setRead(const string & s);	// Set the read sequence.
		void setReadLength(UINT32 rLen);	// Set the length of read.

		string getStringForward(void) const {return read;}
		string getStringReverse(void) const {return readReverse;}
		UINT32 getReadLength(void) const {return readLength;}
		UINT64 getReadNumber(void) const {return readNumber;}
		vector<Edge *> * getListOfEdgesForward(void) const {return listOfEdgesForward;}
		vector<UINT32> * getLocationOnEdgeForward(void) const {return locationOnEdgeForward;}
		vector<Edge *> * getListOfEdgesReverse(void) const {return listOfEdgesReverse;}
		vector<UINT32> * getLocationOnEdgeReverse(void) const {return locationOnEdgeReverse;}

};

string reverseComplement(const string & read);
#endif /* READS_H */
