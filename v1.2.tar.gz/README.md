# omega2 #

You've landed at the page for a overlap-layout-consensus (OLC) metagenome assembler - omega2. 

### Features ###

* Quick summary
omega2 is a massively improved version of [omega](http://bioinformatics.oxfordjournals.org/content/early/2014/07/06/bioinformatics.btu395.short), its unique capabilities include:

    1. Modularization of contained and duplicate reads removal, and initial graph construction after transitive edge reduction step: Big data set can be processed in chunks so that memory limitation problem is solved.

    2. More effective and accurate graph reduction steps result in shorter running time and much higher assembly quality.

    3. We have taken out the module that uses paired end reads to build scaffold since it seems to generate undesired misassemblies. We currently recommend using one of the specialized scaffolding tools. And we have plans to bring the module back with improvement. 

    3. New module where longer accurate reads threading (such as error corrected PacBio reads) can help resolve ambiguity in the overlap graph. - This feature is currently under testing.

* Version
1.0


### How to assemble metagenomic sequencing reads from raw data ###

* Preprocessing of the Illumina data
    1. Since omega2 works best with long reads without errors, therefore preprocessing plays an important role in deciding the quality of the assembly results. We have tested Brian's suite of tools BBTools extensively on the Mock Community Illumina data and have got very good results, better than other tools compared. The steps we currently use are following:
        * Trimming (Q10, mod 5) and adapter filtering
        * Paired end reads merging for the tight insert libraries
        * Error correction with Tadpole.sh 
    2. Contained reads removal. Now that the size of the metagenomic data is continuously increasing, Qiuming developed as part of his tools a program to remove duplicated and contained reads. His program streams the dataset so we can split the big data set into smaller pieces that fit in the limited memory, and remove contained reads in parallel. His tool also supports multi-threading for each of the smaller jobs.
        * Split Big data set into smaller pieces. The following command split the big data file into pieces with about 10G bps each. 

        > splitReads.py -i ${big_sequence_file} -o ${output_prefix} -count 10000000000 -bp

        * Remove duplicated and contained reads

        >${ALIGNER} -i RemoveContainedReads -q ${reads} -s ${reads} -ht omega --ID 0 -t 8 -l ${ovl} -o ${unique_reads}



* Construct overlap graph and remove transitive edges in parallel with Qiuming's tool. Again the new program has the ability to process pieces of the data in parallel in the distributed fashion. Sample commands for one graph construction on data set in one piece and in multiple pieces are following:

> ${ALIGNER} -i ConstructOverlapGraph --TransitiveReduction -q ${unique_reads} -s ${unique_reads} -ht omega --ID 0 -t 8 -l ${ovl} -o ${align_out}
>
> commands to do one piece against whole data set - To be filled in by Qiuming


* Run omega2 for assembly of the Illumina reads

>${OMEGA2} -f ${unique_reads} -e ${align_out} -mld 1000 -mcf 10 -mlr 1000 -o ${omega_out_base}
>
>For all the options of omega2, use 
>
>omega2 -h

* Dependencies: C++11, gcc4.8+

### Questions? ###

* JJ Crosskey crosskey.jj@gmail.com
* Qiuming Yao yao.ornl@gmail.com
* Ted Ahn ahn.no1@gmail.com