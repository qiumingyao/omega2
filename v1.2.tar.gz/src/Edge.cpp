//============================================================================
// Name        : Edge.cpp
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : Edge cpp file
//============================================================================

#include "Config.h"
#include "Edge.h"


Edge::Edge(void)
{
	overlapOffset = 0;
	overlapOrientation = 0;
	flow = 0;
	coverageDepth = 0;
	contigEdgeID = 0;
}


Edge::Edge(Read *from, Read *to, UINT8 orient, UINT32 overlapOffsetInput, 
		vector<pair<UINT32, UINT32> > *mismatchesInput)
{
	source = from;
	destination = to;
	overlapOrientation = orient;
	overlapOffset = overlapOffsetInput;

	contigEdgeID = 0;
	flow = 0;
	coverageDepth = 0;

	mismatches = mismatchesInput;
	mismatches->resize(mismatches->size());

	listOfReads = new vector<UINT64>;
	listOfReads->resize(listOfReads->size());

	listOfOverlapOffsets = new vector<UINT32>;
	listOfOverlapOffsets->resize(listOfOverlapOffsets->size());

	listOfOrientations = new vector<UINT8>;
	listOfOrientations->resize(listOfOrientations->size());
}


Edge::Edge(Read *from, Read *to, UINT8 orient, UINT32 overlapOffsetInput, 
		vector<pair<UINT32, UINT32> > *mismatchesInput, 
		vector<UINT64> *listReads, vector<UINT32> *listOverlapOffsets, 
		vector<UINT8> * listOrientations)
{
	source = from;
	destination = to;
	overlapOrientation = orient;
	overlapOffset = overlapOffsetInput;

	contigEdgeID = 0;
	flow = 0;
	coverageDepth = 0;
	listOfReads = listReads;
	listOfOverlapOffsets = listOverlapOffsets;
	listOfOrientations = listOrientations;

	mismatches = mismatchesInput;
	mismatches->resize(mismatches->size());

	listOfReads->resize(listOfReads->size());
	listOfOverlapOffsets->resize(listOfOverlapOffsets->size());
	listOfOrientations->resize(listOfOrientations->size());	
}



Edge::~Edge()
{
	if(mismatches != nullptr)
		delete mismatches;
	if(listOfReads != nullptr)
		delete listOfReads;
	if(listOfOverlapOffsets != nullptr)
		delete listOfOverlapOffsets;
	if(listOfOrientations != nullptr)
		delete listOfOrientations;
}


/* Get the overlap length for the first link in the edge */
UINT64 Edge::getOverlapLen() const
{
	if(listOfReads->empty())
		return (source->getReadLength() - overlapOffset);
	else
		return (source->getReadLength() - listOfOverlapOffsets->at(0));
}


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  operator<<
 *  Description:  overloading of operator <<, for printing edge information
 * =====================================================================================
 */
ostream& operator<< (ostream &out, Edge &edge)
{
	out << " Orient: " << (int)edge.overlapOrientation << " Flow: " << edge.flow << 
		" Reads: " << (edge.listOfReads)->size() << 
		" Length: " << edge.getEdgeLength() << "\n\t";
	if((edge.listOfReads)->empty())
	{
		out << setw(10) << setfill(' ') << (edge.source)->getReadNumber() << " (--" << setw(4) << setfill(' ') << edge.overlapOffset << ", " << (int)edge.overlapOrientation << "--) " << setw(10) << setfill(' ') << (edge.destination)->getReadNumber();
	}
	else{
		out << setw(10) << setfill(' ') << (edge.source)->getReadNumber() << " (--";
		UINT64 last_ovl_offset = edge.overlapOffset;
		for(UINT64 i = 0; i < (edge.listOfReads)->size(); i++){
			out << setw(4) << setfill(' ') << (edge.listOfOverlapOffsets)->at(i) << ", " 
			    << (int)(edge.listOfOrientations)->at(i) << "--)\n\t" << setw(10) << setfill(' ') << (edge.listOfReads)->at(i) << " (--";
			last_ovl_offset -= (edge.listOfOverlapOffsets)->at(i);
		}
		out << setw(4) << setfill(' ') << last_ovl_offset << "--)\n\t";
		out << setw(10) << setfill(' ') << (edge.destination)->getReadNumber();
	}
	out  << "\n";
	return out;
}
