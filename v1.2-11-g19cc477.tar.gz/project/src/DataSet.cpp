//============================================================================
// Name        : DataSet.cpp
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : DataSet cpp file
//============================================================================

#include "Config.h"
#include "DataSet.h"

DataSet::DataSet(void)
{
	reads = new vector<Read *>;
	numberOfUniqueReads = 0;
}

DataSet::~DataSet()
{
	if (reads != nullptr){
		for(UINT64 i = 0; i < reads->size(); i++)
		{
			if (reads->at(i) != nullptr)
				delete reads->at(i);
		}
		delete reads;
	}
}

Read * DataSet::getReadFromID(UINT64 ID) const
{
	assert(ID >= 1 && ID <= numberOfUniqueReads);
	return reads->at(ID - 1);
}
