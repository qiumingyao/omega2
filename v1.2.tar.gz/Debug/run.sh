./new_omega -f 10reads_duplicate_forward_removed_mismatch.fasta -e 10reads_duplicate_forward_removed_mismatch.align -mlr 10 -mld 10 -mlf 10
