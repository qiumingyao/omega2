#ifndef EDGE_H
#define EDGE_H

//============================================================================
// Name        : Edge.h
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : Edge header file
//============================================================================


#include "Config.h"
#include "Read.h"

class Edge{
	private:
		Read *source;
		Read *destination;

		// 0 = u<-----------<v		reverse of u to reverse of v
		// 1 = u<----------->v		reverse of u to forward of v
		// 2 = u>-----------<v		forward of u to reverse of v
		// 3 = u>----------->v		forward of u to forward of v
		UINT8 overlapOrientation;

		// overlap offset in the following example is 6
		// 	  012345678901234567890123456789
		//	u ACTTACGGGATTATACCATCGAGA
		//	v       GGGATTATACCATCGAGATTCAAT
		UINT32 overlapOffset;

		// mismatch positions in the edge (index, position) where index is from the index of the listOfReads (if simple edge, then 0)
		vector<pair<UINT32, UINT32> > * mismatches;	

		// List of ordered reads in the current edge. NOT including u and v.
		vector<UINT64> * listOfReads;

		// List of overlap offsets of the ordered reads in the current edge.
		// The offset of the destination read is calculated as overlapOffset - sum(listOfOverlapOffsets[i]) or it can retrieved from the reverse edge
		vector<UINT32> * listOfOverlapOffsets; 	
		
		// List of orientations of the ordered reads in the current edge.
		// orientation is 0 or 1. 0 means read's reverse complement read.getStringReverse(). 1 means read's forward string.
		vector<UINT8> * listOfOrientations;

		// This points to the reverse edge in the overlap graph.
		// Each edge (u,v) is present twice in the graph.
		// Edge (u,v) is present in the list of edges of node u
		// Edge (v,u) is present in the list of edges of node v.
		// Edge (u,v) and (v,u) are called twin edge and are reverse of one another.'
		// the reverseEdge always have the same flow as the forward Edge
		// the listOfReads of the reverse edge is the same reads in reverse order as the forward edge
		// the listOfOrientations of the reverse edge is reverse complement
		Edge *reverseEdge;						

	public:
		UINT64 contigEdgeID;
		// Store the flow in the current edge.
		UINT32 flow;

		// Average depth of coverage.
		UINT64 coverageDepth;

		// Standard deviation of the base-by-base coverage depth
		UINT64 SD;

		// Default constructor.
		Edge(void);								

		// constructor for simple edge, length is the overlap length (i.e. length = 18 in the example above)
		Edge(Read *from, Read *to, UINT8 orient, UINT32 overlapOffsetInput, 
				vector<pair<UINT32, UINT32> > *mismatchesInput); 	

		// constructor for composite edge
		Edge(Read *from, Read *to, UINT8 orient, UINT32 overlapOffsetInput, 
				vector<pair<UINT32, UINT32> > *mismatchesInput, 
				vector<UINT64> *listReads, vector<UINT32> *listOverlapOffsets, 
				vector<UINT8> * listOrientations);  

		// Destructor.
		~Edge();								

		friend ostream& operator<< (ostream &out, Edge &edge);

		// Set the pointer to the reverse edge.
		void setReverseEdge(Edge * edge){reverseEdge = edge;}		

		// Get the read object of the source node.
		Read * getSourceRead() const {return source;}	

		// Get the read object of the destination node.
		Read * getDestinationRead() const {return destination; }	

		// Return the orientation of the edge.
		UINT8 getOrientation() const {return overlapOrientation;}	

		// Return the overlap offset.
		UINT32 getOverlapOffset() const {return overlapOffset;}	

		// Get mismatch positions
		vector<pair<UINT32, UINT32> > * getMismatches() const {return mismatches;}

		// Get the ordered list of reads in the current edge.
		vector<UINT64> * getListOfReads() const {return listOfReads;}		

		// Get the list of ordered offset.
		vector<UINT32> * getListOfOverlapOffsets() const {return listOfOverlapOffsets;} 

		// Get the ordered orientation of the reads. 1 means forward. 0 means reverse.
		vector<UINT8> * getListOfOrientations() const {return listOfOrientations;}	

		// Return the pointer to the reverse edge.
		Edge * getReverseEdge() const {return reverseEdge;}	

		void setContigEdgeID(const UINT64 & n) {contigEdgeID = n;}

		INT64 getContigEdgeID (void) const {return contigEdgeID;}

		UINT64 getOverlapLen() const;

		UINT64 getEdgeLength() const {return overlapOffset + destination->getReadLength();}
};

#endif /* EDGE_H */
