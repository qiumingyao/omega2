//============================================================================
// Name        : main.cpp
// Author      : Tae-Hyuk (Ted) Ahn, JJ Crosskey
// Version     : v1.2
// Copyright   : 2015 Oak Ridge National Lab (ORNL). All rights reserved.
// Description : Main code
//============================================================================

#include "Config.h"
#include "DataSet.h"
#include "OverlapGraph.h"
#include "logcpp/log.h"

int OverlapGraph::s_nReads_in_goodEdges = 0;
int OverlapGraph::s_nGoodEdges = 0;
TLogLevel loglevel = logINFO;                   /* verbosity level of logging */
string outputFilenamePrefix = "omega2";

int main(int argc, char **argv) {

	// Parse command line options:
	if(!Config::setConfig(argc, argv)){
		cerr << "Error: wrong configurations" << endl;
		return false;
	}

	CLOCKSTART;
	vector<string> readFilenameList 	= Config::getReadFilenames();
	vector<string> edgeFilenameList 	= Config::getEdgeFilenames();
	outputFilenamePrefix 			= Config::getOutputFilenamePrefix();
	UINT64 minOvl 				= Config::getMinOvl();
	loglevel = FILELog::ReportingLevel();
	FILE_LOG(logINFO) << "Log level is " << FILELog::ReportingLevel() << ":\t" << Config::getLogLevel() << endl;
	FILE_LOG(logINFO) << "Minimum overlap length is: " << minOvl << endl;
	FILE_LOG(logINFO) << "File(s) including reads: ";
	if(loglevel > 1){
		for(vector<std::string>::iterator it = readFilenameList.begin(); it!=readFilenameList.end(); ++it)
			FILE_LOG(logINFO) << *it << "\t";
	}
	FILE_LOG(logINFO) << endl;
	FILE_LOG(logINFO) << "File(s) including edges: ";
	if(loglevel > 1){
		for(vector<std::string>::iterator it = edgeFilenameList.begin(); it!=edgeFilenameList.end(); ++it)
			FILE_LOG(logINFO) << *it;
	}
	FILE_LOG(logINFO) << endl;
	FILE_LOG(logINFO) << "Output file names' prefix is: " << outputFilenamePrefix << endl;
	FILE_LOG(logINFO) << "Maximum read count in dead-end edge is: " << minReadsCountInEdgeToBeNotDeadEnd << endl;
	FILE_LOG(logINFO) << "Maximum edge length in dead-end edge is: " << minEdgeLengthToBeNotDeadEnd << endl;
	FILE_LOG(logINFO) << "Minimum read count in edges with flow is: " << minReadsCountInEdgeToBe1MinFlow << endl;
	FILE_LOG(logINFO) << "Minimum edge length of edges with flow is: " << minEdgeLengthToBe1MinFlow << endl;
	FILE_LOG(logINFO) << "Minimum edge length for edges to be reported is: " << minContigLengthTobeReported << endl;
	FILE_LOG(logINFO) << "Minimum overlap length difference for branches to clip: " << minOvlDiffToClip << endl;
	FILE_LOG(logINFO) << "Minimum fold difference to consider branches to be short: " << minFoldToBeShortBranch << endl;
	
//	FILE_LOG(logINFO) << "Report isolated reads to contigs? " << std::boolalpha << reportUnoverlappedReadsToContigs << endl;


	DataSet *dataSet 			= new DataSet();
	OverlapGraph *overlapGraph 		= new OverlapGraph();

	overlapGraph->setMinOvl(minOvl);
	overlapGraph->setDataSet(dataSet);
	overlapGraph->buildOverlapGraphFromFiles(readFilenameList, edgeFilenameList);
	overlapGraph->simplifyGraph();

	FILE_LOG(logDEBUG) << "loglevel is " << loglevel << endl;
	// Save edges for contigs
  	vector<Edge *> contigEdges;

	if(loglevel > 2){
		overlapGraph->getEdges(contigEdges);
		overlapGraph->printGraph(outputFilenamePrefix+"_graph1.gdl", contigEdges);
		FILE_LOG(logDEBUG) << "loglevel is " << loglevel << endl;
	}
	// Flow analysis
	overlapGraph->calculateFlowStream();
	overlapGraph->removeAllEdgesWithoutFlow();

	// Simplify the graph after the flow.
	overlapGraph->simplifyGraph();

	overlapGraph->getEdges(contigEdges);

	overlapGraph->printGraph(outputFilenamePrefix+"_graph_final.gdl", contigEdges);
	overlapGraph->printContigsStream(readFilenameList, outputFilenamePrefix+"_contigs.fasta", contigEdges);

	delete overlapGraph;
	delete dataSet;

	CLOCKSTOP;
	return 0;
}
